from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject
import os

from .llm.openai_adapter import OpenAIAdapter
from .llm.groq_adapter import GroqAdapter
from .llm.qwen_adapter import QwenAdapter
from .utils.config import Config
from .prompts.system_prompts import QGIS_SYSTEM_PROMPT

class MultiLLMQGISAgent:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.config = Config()
        self.llm_adapter = None
        self.dockwidget = None
        
    def initGui(self):
        """Inicializa a interface do plugin"""
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.action = QAction(
            "Multi-LLM QGIS Agent",
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)

    def initialize_llm(self, provider: str, api_key: str, model: str = None):
        """Inicializa o adaptador LLM selecionado"""
        adapters = {
            'openai': OpenAIAdapter,
            'groq': GroqAdapter,
            'qwen': QwenAdapter
        }
        
        if provider in adapters:
            self.llm_adapter = adapters[provider](api_key, model)
            return self.llm_adapter.test_connection()
        return False
        
    def initialize_llm_from_ui(self):

        """Inicializa o adaptador baseado na UI"""
        provider = self.dockwidget.comboBoxProvider.currentText()
        api_key = self.dockwidget.lineEditApiKey.text()
        
        if not api_key:
            QMessageBox.warning(self.iface.mainWindow(), "Aviso", "Por favor, insira uma chave API.")
            return False
            
        success = self.initialize_llm(provider, api_key)
        if success:
            self.config.set_api_key(provider, api_key)
            self.config.set_last_provider(provider)
            QMessageBox.information(self.iface.mainWindow(), "Sucesso", f"Conectado ao {provider} com sucesso!")
        else:
            QMessageBox.critical(self.iface.mainWindow(), "Erro", f"Falha ao conectar ao {provider}. Verifique a chave e a rede.")
        return success

    def on_send_command(self):
        """Processa o comando da UI"""
        command = self.dockwidget.lineEditCommand.text()
        if not command:
            return

        # Garante que o LLM está inicializado
        if not self.llm_adapter:
            if not self.initialize_llm_from_ui():
                return

        self.iface.mainWindow().statusBar().showMessage("Processando comando...")
        result = self.process_command(command)
        
        if result['success']:
            self.dockwidget.textEditCode.setPlainText(result['code'] or result['response'])
        else:
            QMessageBox.warning(self.iface.mainWindow(), "Erro no LLM", result['error'])
        
        self.iface.mainWindow().statusBar().clearMessage()

    def on_execute_code(self):
        """Executa o código da UI"""
        code = self.dockwidget.textEditCode.toPlainText()
        if code:
            self.execute_code(code)

    def run(self):
        """Ação principal do plugin"""
        if not self.dockwidget:
            from .agent_dockwidget import AgentDockWidget
            self.dockwidget = AgentDockWidget()
            
            # Carrega configurações salvas
            provider = self.config.get_last_provider()
            self.dockwidget.comboBoxProvider.setCurrentText(provider)
            self.dockwidget.lineEditApiKey.setText(self.config.get_api_key(provider))
            
            # Conecta sinais
            self.dockwidget.pushButtonSend.clicked.connect(self.on_send_command)
            self.dockwidget.pushButtonExecute.clicked.connect(self.on_execute_code)
            self.dockwidget.pushButtonTestConnection.clicked.connect(self.initialize_llm_from_ui)
            self.dockwidget.closingPlugin.connect(self.on_dockwidget_closed)

        # Mostra o dockwidget
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
        self.dockwidget.show()

    def on_dockwidget_closed(self):
        """Limpa quando o dockwidget é fechado"""
        pass

    def unload(self):
        """Remove o plugin do QGIS"""
        if self.action:
            self.iface.removeToolBarIcon(self.action)
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)

