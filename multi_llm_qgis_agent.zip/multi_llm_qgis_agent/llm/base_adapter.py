from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class BaseLLMAdapter(ABC):
    """Classe base abstrata para todos os adaptadores LLM"""
    
    def __init__(self, api_key: str, model: str = None):
        self.api_key = api_key
        self.model = model
        self.default_temperature = 0.3
    
    @abstractmethod
    def generate_response(
        self, 
        prompt: str, 
        system_prompt: str = None,
        temperature: float = None
    ) -> Dict[str, Any]:
        """
        Gera resposta do LLM
        
        Returns:
            {
                'success': bool,
                'response': str,
                'code': str or None,
                'error': str or None
            }
        """
        pass
    
    @abstractmethod
    def test_connection(self) -> bool:
        """Testa conexão com a API"""
        pass
    
    def extract_code(self, response: str) -> Optional[str]:
        """Extrai código Python da resposta"""
        if '```python' in response:
            code = response.split('```python')[1].split('```')[0]
            return code.strip()
        elif '```' in response:
            # Fallback for generic blocks if python is not specified
            code = response.split('```')[1].split('```')[0]
            return code.strip()
        return None
