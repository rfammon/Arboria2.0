/**
 * AICodeQualityAnalyzer - AI-powered code quality analysis and improvement
 * 
 * Uses Vercel AI SDK to provide intelligent code quality analysis including:
 * - Advanced code smell pattern detection
 * - Refactoring opportunity identification with confidence scoring
 * - Architecture violation pattern analysis
 * - Technical debt accumulation tracking and prioritization
 */

import { EventEmitter } from "events";
import { generateObject, generateText } from "ai";
import { openai } from "@ai-sdk/openai";
import { z } from "zod";
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { ViolationInfo, ComplexityAnalysis } from "../core/DebuggerCore.js";

// Zod schemas for structured AI outputs
const CodeSmellAnalysisSchema = z.object({
  codeSmells: z.array(z.object({
    type: z.enum([
      "long_method",
      "large_class",
      "duplicate_code",
      "dead_code",
      "god_object",
      "feature_envy",
      "data_clumps",
      "primitive_obsession",
      "switch_statements",
      "lazy_class",
      "speculative_generality",
      "temporary_field",
      "message_chains",
      "middle_man",
      "inappropriate_intimacy",
      "alternative_classes",
      "incomplete_library",
      "data_class",
      "refused_bequest",
      "comments"
    ]).describe("Type of code smell detected"),
    severity: z.enum(["critical", "high", "medium", "low"]).describe("Severity of the code smell"),
    location: z.string().describe("File and line where the smell occurs"),
    description: z.string().describe("Description of the code smell"),
    impact: z.string().describe("Impact on maintainability and quality"),
    confidence: z.number().min(0).max(1).describe("Confidence in detection"),
    suggestion: z.string().describe("Suggested refactoring approach")
  })),
  overallQualityScore: z.number().min(0).max(100).describe("Overall code quality score"),
  maintainabilityIndex: z.number().min(0).max(100).describe("Maintainability index")
});

const RefactoringOpportunitySchema = z.object({
  opportunities: z.array(z.object({
    type: z.enum([
      "extract_method",
      "extract_class",
      "move_method",
      "move_field",
      "inline_method",
      "inline_class",
      "replace_temp_with_query",
      "introduce_parameter_object",
      "preserve_whole_object",
      "replace_method_with_method_object",
      "substitute_algorithm",
      "decompose_conditional",
      "consolidate_conditional",
      "remove_control_flag",
      "replace_nested_conditional",
      "introduce_assertion",
      "separate_query_from_modifier",
      "parameterize_method",
      "replace_parameter_with_explicit_methods",
      "replace_constructor_with_factory"
    ]).describe("Type of refactoring opportunity"),
    title: z.string().describe("Short title for the refactoring"),
    description: z.string().describe("Detailed description of the opportunity"),
    location: z.string().describe("Where the refactoring should be applied"),
    effort: z.enum(["low", "medium", "high"]).describe("Effort required for refactoring"),
    impact: z.enum(["low", "medium", "high"]).describe("Impact on code quality"),
    confidence: z.number().min(0).max(1).describe("Confidence in this opportunity"),
    codeExample: z.string().optional().describe("Example of how to refactor"),
    priority: z.number().min(1).max(10).describe("Priority score (1-10)")
  })),
  quickWins: z.array(z.string()).describe("Quick refactoring wins"),
  architecturalImprovements: z.array(z.string()).describe("Architectural improvements needed")
});

const TechnicalDebtSchema = z.object({
  debtItems: z.array(z.object({
    category: z.enum([
      "code_debt",
      "design_debt",
      "test_debt",
      "documentation_debt",
      "infrastructure_debt",
      "performance_debt",
      "security_debt",
      "dependency_debt"
    ]).describe("Category of technical debt"),
    title: z.string().describe("Title of the debt item"),
    description: z.string().describe("Description of the technical debt"),
    location: z.string().describe("Where the debt exists"),
    severity: z.enum(["critical", "high", "medium", "low"]).describe("Severity of the debt"),
    estimatedCost: z.string().describe("Estimated cost to fix (time/effort)"),
    riskLevel: z.enum(["high", "medium", "low"]).describe("Risk if left unfixed"),
    recommendation: z.string().describe("Recommended approach to address debt"),
    priority: z.number().min(1).max(10).describe("Priority for addressing this debt")
  })),
  totalDebtScore: z.number().min(0).max(100).describe("Overall technical debt score"),
  debtTrend: z.enum(["increasing", "stable", "decreasing"]).describe("Trend in technical debt"),
  criticalItems: z.array(z.string()).describe("Most critical debt items to address")
});

export interface CodeSmell {
  id: string;
  type: string;
  severity: "critical" | "high" | "medium" | "low";
  location: string;
  description: string;
  impact: string;
  confidence: number;
  suggestion: string;
  detectedAt: Date;
  status: "open" | "investigating" | "fixed" | "ignored";
}

export interface RefactoringOpportunity {
  id: string;
  type: string;
  title: string;
  description: string;
  location: string;
  effort: "low" | "medium" | "high";
  impact: "low" | "medium" | "high";
  confidence: number;
  codeExample?: string;
  priority: number;
  createdAt: Date;
  status: "pending" | "in_progress" | "completed" | "dismissed";
}

export interface TechnicalDebtItem {
  id: string;
  category: string;
  title: string;
  description: string;
  location: string;
  severity: "critical" | "high" | "medium" | "low";
  estimatedCost: string;
  riskLevel: "high" | "medium" | "low";
  recommendation: string;
  priority: number;
  createdAt: Date;
  resolvedAt?: Date;
}

export interface CodeQualityInsight {
  overallQualityScore: number;
  maintainabilityIndex: number;
  codeSmells: CodeSmell[];
  refactoringOpportunities: RefactoringOpportunity[];
  technicalDebt: TechnicalDebtItem[];
  totalDebtScore: number;
  debtTrend: "increasing" | "stable" | "decreasing";
  criticalItems: string[];
  lastAnalyzed: Date;
}

export class AICodeQualityAnalyzer extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private codeSmells: Map<string, CodeSmell> = new Map();
  private refactoringOpportunities: Map<string, RefactoringOpportunity> = new Map();
  private technicalDebt: Map<string, TechnicalDebtItem> = new Map();
  private qualityHistory: Array<{ timestamp: Date; score: number }> = [];
  private aiModel: any;

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("AICodeQualityAnalyzer");
    this.configManager = configManager;
    
    // Initialize AI model
    const config = this.configManager.getConfig();

    // Check if AI is enabled and API key is available
    if (config.ai?.enabled && (config.ai?.apiKey || process.env.OPENAI_API_KEY)) {
      this.aiModel = openai(config.ai?.model || 'gpt-4o-mini');
    } else {
      this.logger.warn("AI features disabled: No API key provided or AI disabled in config");
      this.aiModel = null;
    }
  }

  async initialize(): Promise<void> {
    this.logger.info("AICodeQualityAnalyzer initialized with AI-powered analysis");
  }

  /**
   * Analyze code quality using AI
   */
  async analyzeCodeQuality(
    violations: ViolationInfo[],
    complexityAnalyses: ComplexityAnalysis[],
    codeContent?: string
  ): Promise<CodeQualityInsight> {
    try {
      this.logger.debug(`Analyzing code quality with ${violations.length} violations and ${complexityAnalyses.length} complexity analyses`);

      // Check if AI is available
      if (!this.aiModel) {
        return this.createFallbackInsight(violations, complexityAnalyses);
      }

      // Prepare data for AI analysis
      const analysisData = this.prepareAnalysisData(violations, complexityAnalyses, codeContent);

      // Detect code smells using AI
      const { object: codeSmellAnalysis } = await generateObject({
        model: this.aiModel,
        schema: CodeSmellAnalysisSchema,
        prompt: `Analyze this code for code smells and quality issues:

Code Analysis Data:
${JSON.stringify(analysisData, null, 2)}

Identify:
1. Code smells and anti-patterns
2. Quality issues that affect maintainability
3. Areas where code could be improved
4. Overall quality assessment

Focus on React/TypeScript/Next.js specific patterns and best practices.`,
      });

      // Identify refactoring opportunities
      const { object: refactoringAnalysis } = await generateObject({
        model: this.aiModel,
        schema: RefactoringOpportunitySchema,
        prompt: `Based on this code analysis, identify refactoring opportunities:

Code Smells Found:
${JSON.stringify(codeSmellAnalysis.codeSmells, null, 2)}

Analysis Data:
${JSON.stringify(analysisData, null, 2)}

Provide:
1. Specific refactoring opportunities with clear benefits
2. Implementation guidance and code examples
3. Effort vs impact analysis
4. Quick wins and architectural improvements

Focus on modern React/TypeScript patterns and best practices.`,
      });

      // Analyze technical debt
      const { object: debtAnalysis } = await generateObject({
        model: this.aiModel,
        schema: TechnicalDebtSchema,
        prompt: `Analyze technical debt in this codebase:

Code Quality Issues:
${JSON.stringify(codeSmellAnalysis.codeSmells, null, 2)}

Violations:
${JSON.stringify(violations.slice(0, 20), null, 2)} // Limit for AI processing

Complexity Data:
${JSON.stringify(complexityAnalyses.slice(0, 10), null, 2)}

Identify:
1. Technical debt items by category
2. Risk assessment for each debt item
3. Prioritization based on impact and effort
4. Trend analysis and recommendations

Focus on maintainability, scalability, and long-term code health.`,
      });

      // Convert AI analysis to our data structures
      const codeSmells = this.convertCodeSmells(codeSmellAnalysis.codeSmells);
      const opportunities = this.convertRefactoringOpportunities(refactoringAnalysis.opportunities);
      const debtItems = this.convertTechnicalDebt(debtAnalysis.debtItems);

      // Update quality history
      this.qualityHistory.push({
        timestamp: new Date(),
        score: codeSmellAnalysis.overallQualityScore
      });

      // Keep only recent history (last 100 entries)
      if (this.qualityHistory.length > 100) {
        this.qualityHistory = this.qualityHistory.slice(-100);
      }

      const insight: CodeQualityInsight = {
        overallQualityScore: codeSmellAnalysis.overallQualityScore,
        maintainabilityIndex: codeSmellAnalysis.maintainabilityIndex,
        codeSmells,
        refactoringOpportunities: opportunities,
        technicalDebt: debtItems,
        totalDebtScore: debtAnalysis.totalDebtScore,
        debtTrend: debtAnalysis.debtTrend,
        criticalItems: debtAnalysis.criticalItems,
        lastAnalyzed: new Date()
      };

      this.emit('codeQualityAnalyzed', insight);
      this.logger.info(`Code quality analysis complete: score ${codeSmellAnalysis.overallQualityScore}/100, ${codeSmells.length} smells, ${opportunities.length} opportunities`);

      return insight;

    } catch (error) {
      this.logger.error("Failed to analyze code quality with AI:", error);
      throw error;
    }
  }

  /**
   * Get code quality insights
   */
  getCodeQualityInsights(): CodeQualityInsight {
    const latestScore = this.qualityHistory.length > 0
      ? this.qualityHistory[this.qualityHistory.length - 1]?.score || 0
      : 0;

    return {
      overallQualityScore: latestScore,
      maintainabilityIndex: this.calculateMaintainabilityIndex(),
      codeSmells: Array.from(this.codeSmells.values()),
      refactoringOpportunities: Array.from(this.refactoringOpportunities.values()),
      technicalDebt: Array.from(this.technicalDebt.values()),
      totalDebtScore: this.calculateTotalDebtScore(),
      debtTrend: this.calculateDebtTrend(),
      criticalItems: this.getCriticalItems(),
      lastAnalyzed: new Date()
    };
  }

  /**
   * Get code smells by severity
   */
  getCodeSmellsBySeverity(severity: "critical" | "high" | "medium" | "low"): CodeSmell[] {
    return Array.from(this.codeSmells.values()).filter(s => s.severity === severity);
  }

  /**
   * Get refactoring opportunities by impact
   */
  getRefactoringOpportunitiesByImpact(impact: "high" | "medium" | "low"): RefactoringOpportunity[] {
    return Array.from(this.refactoringOpportunities.values())
      .filter(o => o.impact === impact)
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * Get technical debt by category
   */
  getTechnicalDebtByCategory(category: string): TechnicalDebtItem[] {
    return Array.from(this.technicalDebt.values()).filter(d => d.category === category);
  }

  /**
   * Prepare analysis data for AI
   */
  private prepareAnalysisData(
    violations: ViolationInfo[],
    complexityAnalyses: ComplexityAnalysis[],
    codeContent?: string
  ): any {
    return {
      violations: violations.slice(0, 50), // Limit for AI processing
      complexity: complexityAnalyses.slice(0, 20),
      codeSnippet: codeContent?.substring(0, 2000), // First 2000 chars
      summary: {
        totalViolations: violations.length,
        severityBreakdown: this.getViolationSeverityBreakdown(violations),
        complexityStats: this.getComplexityStats(complexityAnalyses),
        fileTypes: this.getFileTypeBreakdown(violations)
      }
    };
  }

  /**
   * Convert AI code smell analysis to our data structure
   */
  private convertCodeSmells(aiCodeSmells: any[]): CodeSmell[] {
    return aiCodeSmells.map(s => {
      const codeSmell: CodeSmell = {
        id: `smell_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: s.type,
        severity: s.severity,
        location: s.location,
        description: s.description,
        impact: s.impact,
        confidence: s.confidence,
        suggestion: s.suggestion,
        detectedAt: new Date(),
        status: "open"
      };

      this.codeSmells.set(codeSmell.id, codeSmell);
      return codeSmell;
    });
  }

  /**
   * Convert AI refactoring opportunities to our data structure
   */
  private convertRefactoringOpportunities(aiOpportunities: any[]): RefactoringOpportunity[] {
    return aiOpportunities.map(o => {
      const opportunity: RefactoringOpportunity = {
        id: `refactor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: o.type,
        title: o.title,
        description: o.description,
        location: o.location,
        effort: o.effort,
        impact: o.impact,
        confidence: o.confidence,
        codeExample: o.codeExample,
        priority: o.priority,
        createdAt: new Date(),
        status: "pending"
      };

      this.refactoringOpportunities.set(opportunity.id, opportunity);
      return opportunity;
    });
  }

  /**
   * Convert AI technical debt analysis to our data structure
   */
  private convertTechnicalDebt(aiDebtItems: any[]): TechnicalDebtItem[] {
    return aiDebtItems.map(d => {
      const debtItem: TechnicalDebtItem = {
        id: `debt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: d.category,
        title: d.title,
        description: d.description,
        location: d.location,
        severity: d.severity,
        estimatedCost: d.estimatedCost,
        riskLevel: d.riskLevel,
        recommendation: d.recommendation,
        priority: d.priority,
        createdAt: new Date()
      };

      this.technicalDebt.set(debtItem.id, debtItem);
      return debtItem;
    });
  }

  /**
   * Get violation severity breakdown
   */
  private getViolationSeverityBreakdown(violations: ViolationInfo[]): any {
    const breakdown = { error: 0, warning: 0, info: 0 };
    violations.forEach(v => {
      breakdown[v.severity as keyof typeof breakdown]++;
    });
    return breakdown;
  }

  /**
   * Get complexity statistics
   */
  private getComplexityStats(complexityAnalyses: ComplexityAnalysis[]): any {
    if (complexityAnalyses.length === 0) return {};

    const complexities = complexityAnalyses.map(c => c.metrics.cyclomaticComplexity);
    const avgComplexity = complexities.reduce((a, b) => a + b, 0) / complexities.length;
    const maxComplexity = Math.max(...complexities);

    return {
      averageComplexity: avgComplexity,
      maxComplexity: maxComplexity,
      highComplexityFiles: complexityAnalyses.filter(c => c.metrics.cyclomaticComplexity > 10).length
    };
  }

  /**
   * Get file type breakdown
   */
  private getFileTypeBreakdown(violations: ViolationInfo[]): any {
    const breakdown: Record<string, number> = {};
    violations.forEach(v => {
      const ext = v.file.split('.').pop() || 'unknown';
      breakdown[ext] = (breakdown[ext] || 0) + 1;
    });
    return breakdown;
  }

  /**
   * Calculate maintainability index
   */
  private calculateMaintainabilityIndex(): number {
    const codeSmellPenalty = this.codeSmells.size * 2;
    const debtPenalty = this.technicalDebt.size * 3;
    
    let index = 100 - codeSmellPenalty - debtPenalty;
    return Math.max(0, Math.min(100, index));
  }

  /**
   * Calculate total debt score
   */
  private calculateTotalDebtScore(): number {
    const debtItems = Array.from(this.technicalDebt.values());
    if (debtItems.length === 0) return 0;

    const totalPriority = debtItems.reduce((sum, item) => sum + item.priority, 0);
    return Math.min(100, (totalPriority / debtItems.length) * 10);
  }

  /**
   * Calculate debt trend
   */
  private calculateDebtTrend(): "increasing" | "stable" | "decreasing" {
    if (this.qualityHistory.length < 5) return "stable";

    const recent = this.qualityHistory.slice(-5);
    const trend = (recent[recent.length - 1]?.score || 0) - (recent[0]?.score || 0);

    if (trend > 5) return "decreasing"; // Quality improving = debt decreasing
    if (trend < -5) return "increasing"; // Quality degrading = debt increasing
    return "stable";
  }

  /**
   * Get critical items that need immediate attention
   */
  private getCriticalItems(): string[] {
    const critical: string[] = [];

    // Critical code smells
    this.getCodeSmellsBySeverity("critical").forEach(smell => {
      critical.push(`Code Smell: ${smell.type} in ${smell.location}`);
    });

    // High-priority technical debt
    Array.from(this.technicalDebt.values())
      .filter(debt => debt.severity === "critical" || debt.priority >= 8)
      .forEach(debt => {
        critical.push(`Technical Debt: ${debt.title}`);
      });

    return critical.slice(0, 10); // Limit to top 10
  }

  /**
   * Create fallback insight when AI is not available
   */
  private createFallbackInsight(
    violations: ViolationInfo[],
    complexityAnalyses: ComplexityAnalysis[]
  ): CodeQualityInsight {
    // Simple rule-based analysis
    const codeSmells: CodeSmell[] = [];
    const refactoringOpportunities: RefactoringOpportunity[] = [];
    const technicalDebt: TechnicalDebtItem[] = [];

    // Analyze violations for code smells
    violations.forEach(violation => {
      if (violation.severity === "error") {
        codeSmells.push({
          id: `smell_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          type: "code_debt",
          severity: "high",
          location: `${violation.file}:${violation.line}`,
          description: violation.message,
          impact: "Affects code maintainability",
          confidence: 0.8,
          suggestion: "Fix the reported violation",
          detectedAt: new Date(),
          status: "open"
        });
      }
    });

    // Analyze complexity for refactoring opportunities
    complexityAnalyses.forEach(analysis => {
      if (analysis.metrics.cyclomaticComplexity > 10) {
        refactoringOpportunities.push({
          id: `refactor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          type: "extract_method",
          title: "Reduce Complexity",
          description: `High complexity detected (${analysis.metrics.cyclomaticComplexity})`,
          location: analysis.file,
          effort: "medium",
          impact: "high",
          confidence: 0.9,
          priority: 7,
          createdAt: new Date(),
          status: "pending"
        });
      }
    });

    // Create technical debt items based on violations
    if (violations.length > 20) {
      technicalDebt.push({
        id: `debt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: "code_debt",
        title: "High Violation Count",
        description: `${violations.length} code violations detected`,
        location: "Multiple files",
        severity: "medium",
        estimatedCost: "2-3 days",
        riskLevel: "medium",
        recommendation: "Address violations systematically",
        priority: 6,
        createdAt: new Date()
      });
    }

    const qualityScore = Math.max(0, 100 - (violations.length * 2) - (codeSmells.length * 5));

    const insight: CodeQualityInsight = {
      overallQualityScore: qualityScore,
      maintainabilityIndex: Math.max(0, 100 - (codeSmells.length * 3)),
      codeSmells,
      refactoringOpportunities,
      technicalDebt,
      totalDebtScore: technicalDebt.length * 10,
      debtTrend: "stable",
      criticalItems: [
        ...codeSmells.filter(s => s.severity === "critical").map(s => `Code Smell: ${s.type}`),
        ...technicalDebt.filter(d => d.severity === "critical").map(d => `Technical Debt: ${d.title}`)
      ],
      lastAnalyzed: new Date()
    };

    this.emit('codeQualityAnalyzed', insight);
    return insight;
  }

  async shutdown(): Promise<void> {
    this.logger.info("AICodeQualityAnalyzer shutdown complete");
  }
}
