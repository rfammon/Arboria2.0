'use client';

import React, { useState, useEffect } from 'react';

// Component with intentional issues for testing the debugger
interface ProblematicComponentProps {
  title: string;
  data: any; // Issue: using 'any' type
  count: number;
  isVisible: boolean;
  onUpdate: (value: string) => void;
  extraProp1?: string;
  extraProp2?: number;
  extraProp3?: boolean;
  extraProp4?: object;
  extraProp5?: string; // Issue: Too many props (10 > 8)
}

// Issue: Bad naming convention - should be camelCase
const helper_function_with_bad_name = (input: string) => {
  // Issue: High cyclomatic complexity
  if (input.length > 0) {
    if (input.includes('test')) {
      if (input.startsWith('test')) {
        if (input.endsWith('test')) {
          if (input.length > 10) {
            if (input.includes('complex')) {
              if (input.includes('very')) {
                return 'very very complex';
              } else {
                return 'very complex';
              }
            } else {
              return 'complex';
            }
          } else {
            return 'simple';
          }
        } else {
          return 'starts with test';
        }
      } else {
        return 'contains test';
      }
    } else {
      return 'no test';
    }
  } else {
    return 'empty';
  }
};

// Issue: Function with too many parameters
const functionWithTooManyParams = (
  param1: string,
  param2: number,
  param3: boolean,
  param4: object,
  param5: string,
  param6: number,
  param7: boolean // 7 parameters > 5 threshold
) => {
  return `${param1}-${param2}-${param3}-${param4}-${param5}-${param6}-${param7}`;
};

const ProblematicComponent: React.FC<ProblematicComponentProps> = ({
  title,
  data,
  count,
  isVisible,
  onUpdate,
  extraProp1,
  extraProp2,
  extraProp3,
  extraProp4,
  extraProp5
}) => {
  const [localState, setLocalState] = useState<string>('');
  const [counter, setCounter] = useState<number>(0);
  const [errors, setErrors] = useState<string[]>([]);

  // Issue: Missing dependency in useEffect
  useEffect(() => {
    console.log('Component mounted');
    setLocalState(title); // 'title' should be in dependency array
  }, []); // Missing 'title' dependency

  // Issue: Memory leak - no cleanup
  useEffect(() => {
    const interval = setInterval(() => {
      setCounter(prev => prev + 1);
    }, 1000);
    // Missing cleanup function
  }, []);

  // Issue: Another useEffect with missing dependencies
  useEffect(() => {
    if (count > 10) {
      setLocalState(`High count: ${count}`);
    }
  }, []); // Missing 'count' dependency

  // Issue: Expensive operation in render (performance problem)
  const expensiveCalculation = () => {
    let result = 0;
    for (let i = 0; i < 100000; i++) {
      result += Math.random() * Math.sin(i) * Math.cos(i);
    }
    return result.toFixed(2);
  };

  // Issue: Function that throws errors for testing error tracking
  const triggerError = () => {
    throw new Error('Intentional error for testing error tracking');
  };

  const triggerAsyncError = async () => {
    // Issue: Unhandled promise rejection
    Promise.reject(new Error('Unhandled async error'));
  };

  const triggerNetworkError = async () => {
    try {
      // Issue: Network request that will fail
      await fetch('https://nonexistent-api-endpoint-12345.com/data');
    } catch (error) {
      console.error('Network error:', error);
    }
  };

  // Issue: Nested component definition (bad practice)
  const NestedComponent = ({ text }: { text: string }) => {
    return <span style={{ color: 'red' }}>{text}</span>; // Issue: inline styles
  };

  // Issue: Complex nested JSX with deep nesting
  const renderComplexContent = () => {
    return (
      <div>
        <div>
          <div>
            <div>
              <div>
                <div>
                  <span>Too deeply nested content</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="p-4 border rounded">
      {/* Issue: Inline styles */}
      <h1 style={{ fontSize: '24px', color: 'blue', marginBottom: '16px' }}>
        {title}
      </h1>
      
      <div style={{ backgroundColor: '#f0f0f0', padding: '10px' }}>
        <p>Count: {count}</p>
        <p>Local State: {localState}</p>
        <p>Counter: {counter}</p>
        <p>Expensive Calculation: {expensiveCalculation()}</p>
        <p>Helper Result: {helper_function_with_bad_name(localState)}</p>
        
        <NestedComponent text="This is a nested component" />
        
        {renderComplexContent()}
        
        <div className="mt-4 space-x-2">
          <button 
            onClick={() => onUpdate(localState)}
            className="px-4 py-2 bg-blue-500 text-white rounded"
          >
            Update Parent
          </button>
          
          <button 
            onClick={triggerError}
            className="px-4 py-2 bg-red-500 text-white rounded"
          >
            Trigger Error
          </button>
          
          <button 
            onClick={triggerAsyncError}
            className="px-4 py-2 bg-orange-500 text-white rounded"
          >
            Trigger Async Error
          </button>
          
          <button 
            onClick={triggerNetworkError}
            className="px-4 py-2 bg-purple-500 text-white rounded"
          >
            Trigger Network Error
          </button>
        </div>
        
        {errors.length > 0 && (
          <div className="mt-4 p-2 bg-red-100 border border-red-400 rounded">
            <h3>Errors:</h3>
            <ul>
              {errors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProblematicComponent;
