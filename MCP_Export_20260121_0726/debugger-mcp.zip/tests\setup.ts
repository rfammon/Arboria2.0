/**
 * Global test setup for all test files
 * This file is loaded before all tests to set up global mocks
 */

import { vi } from 'vitest';

// Global v8-profiler-next mock with proper getDuration method
vi.mock('v8-profiler-next', async (importOriginal) => {
  const actual = await importOriginal();
  return {
    ...actual,
    startProfiling: vi.fn(),
    stopProfiling: vi.fn(() => ({
      getDuration: vi.fn(() => 1000), // Return duration in microseconds
      export: vi.fn(() => ({ 
        head: { 
          functionName: 'test', 
          hitCount: 5,
          children: []
        } 
      })),
      delete: vi.fn()
    }))
  };
});

// Global Puppeteer mock
vi.mock('puppeteer', () => ({
  default: {
    connect: vi.fn(),
    launch: vi.fn()
  }
}));
