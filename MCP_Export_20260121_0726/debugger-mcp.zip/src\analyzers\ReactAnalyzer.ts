import { Logger } from '../utils/Logger.js';
import * as babel from '@babel/parser';
import * as t from '@babel/types';
import { createRequire } from 'module';

// Use createRequire for traverse to handle ES module compatibility
const require = createRequire(import.meta.url);
const traverse = require('@babel/traverse').default || require('@babel/traverse');

/**
 * React-specific analysis results
 */
export interface ReactAnalysisResult {
  components: ComponentAnalysis[];
  hooks: HookAnalysis[];
  issues: ReactIssue[];
  performance: ReactPerformanceMetrics;
}

export interface ComponentAnalysis {
  name: string;
  type: 'functional' | 'class';
  filePath: string;
  lineNumber: number;
  props: PropAnalysis[];
  state: StateAnalysis[];
  hooks: string[];
  renderComplexity: number;
  issues: ComponentIssue[];
}

export interface PropAnalysis {
  name: string;
  type: string;
  required: boolean;
  defaultValue?: string;
  drilling: boolean; // Props drilling detection
}

export interface StateAnalysis {
  name: string;
  type: string;
  initialValue?: string;
  mutations: number;
}

export interface HookAnalysis {
  name: string;
  type: string;
  filePath: string;
  lineNumber: number;
  dependencies: string[];
  missingDependencies: string[];
  issues: HookIssue[];
}

export interface ReactIssue {
  type: 'component' | 'hook' | 'performance' | 'pattern';
  severity: 'error' | 'warning' | 'info';
  message: string;
  filePath: string;
  lineNumber: number;
  suggestion?: string;
}

export interface ComponentIssue extends ReactIssue {
  componentName: string;
}

export interface HookIssue extends ReactIssue {
  hookName: string;
}

export interface ReactPerformanceMetrics {
  unnecessaryRerenders: number;
  heavyComponents: string[];
  optimizationOpportunities: string[];
}

/**
 * Analyzes React components, hooks, and patterns for best practices and performance
 */
export class ReactAnalyzer {
  private logger: Logger;

  constructor() {
    this.logger = new Logger('ReactAnalyzer');
  }

  /**
   * Analyze a React file for components, hooks, and issues
   */
  async analyzeFile(filePath: string, content: string): Promise<ReactAnalysisResult> {
    try {
      const ast = babel.parse(content, {
        sourceType: 'module',
        plugins: ['jsx', 'typescript', 'decorators-legacy']
      });

      const result: ReactAnalysisResult = {
        components: [],
        hooks: [],
        issues: [],
        performance: {
          unnecessaryRerenders: 0,
          heavyComponents: [],
          optimizationOpportunities: []
        }
      };

      traverse(ast, {
        // Analyze functional components
        FunctionDeclaration: (path: any) => {
          if (this.isReactComponent(path.node)) {
            const component = this.analyzeComponent(path, filePath);
            result.components.push(component);
            result.issues.push(...component.issues);
          }
        },

        // Analyze arrow function components
        VariableDeclarator: (path: any) => {
          if (t.isArrowFunctionExpression(path.node.init) || t.isFunctionExpression(path.node.init)) {
            if (this.isReactComponent(path.node.init)) {
              const component = this.analyzeArrowComponent(path, filePath);
              result.components.push(component);
              result.issues.push(...component.issues);
            }
          }
        },

        // Analyze class components
        ClassDeclaration: (path: any) => {
          if (this.isReactClassComponent(path.node)) {
            const component = this.analyzeClassComponent(path, filePath);
            result.components.push(component);
            result.issues.push(...component.issues);
          }
        },

        // Analyze hooks
        CallExpression: (path: any) => {
          if (this.isHookCall(path.node)) {
            const hook = this.analyzeHook(path, filePath);
            result.hooks.push(hook);
            result.issues.push(...hook.issues);
          }
        }
      });

      // Analyze performance issues
      this.analyzePerformanceIssues(result);

      this.logger.info(`Analyzed React file: ${filePath}`, {
        components: result.components.length,
        hooks: result.hooks.length,
        issues: result.issues.length
      });

      return result;
    } catch (error) {
      this.logger.error('Failed to analyze React file', { filePath, error });
      throw error;
    }
  }

  /**
   * Check if a function is a React component
   */
  private isReactComponent(node: t.Function): boolean {
    // Check if function name starts with uppercase (React convention)
    if (t.isFunctionDeclaration(node) && node.id) {
      const name = node.id.name;
      return name.length > 0 && name.charAt(0) === name.charAt(0).toUpperCase();
    }

    // Check if function returns JSX by examining the function body
    let returnsJSX = false;

    // Simple check for JSX in function body
    const checkForJSX = (node: any): boolean => {
      if (t.isJSXElement(node) || t.isJSXFragment(node)) {
        return true;
      }
      if (t.isReturnStatement(node) && node.argument) {
        return checkForJSX(node.argument);
      }
      if (t.isBlockStatement(node) && node.body) {
        return node.body.some((stmt: any) => checkForJSX(stmt));
      }
      if (t.isArrowFunctionExpression(node) && node.body) {
        return checkForJSX(node.body);
      }
      return false;
    };

    returnsJSX = checkForJSX(node.body || node);

    return returnsJSX;
  }

  /**
   * Check if a class is a React component
   */
  private isReactClassComponent(node: t.ClassDeclaration): boolean {
    // Check if extends React.Component or Component
    if (node.superClass) {
      if (t.isMemberExpression(node.superClass)) {
        return (
          t.isIdentifier(node.superClass.object, { name: 'React' }) &&
          t.isIdentifier(node.superClass.property, { name: 'Component' })
        );
      }
      if (t.isIdentifier(node.superClass, { name: 'Component' })) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check if a call expression is a React hook
   */
  private isHookCall(node: t.CallExpression): boolean {
    if (t.isIdentifier(node.callee)) {
      return node.callee.name.startsWith('use') && node.callee.name.length > 3;
    }
    return false;
  }

  /**
   * Analyze a functional component
   */
  private analyzeComponent(path: any, filePath: string): ComponentAnalysis {
    const node = path.node;
    const name = node.id?.name || 'Anonymous';
    const issues: ComponentIssue[] = [];

    // Analyze component complexity
    const renderComplexity = this.calculateRenderComplexity(node);
    if (renderComplexity > 10) {
      issues.push({
        type: 'component',
        severity: 'warning',
        message: `Component "${name}" has high render complexity (${renderComplexity})`,
        filePath,
        lineNumber: node.loc?.start.line || 0,
        componentName: name,
        suggestion: 'Consider breaking this component into smaller components'
      });
    }

    return {
      name,
      type: 'functional',
      filePath,
      lineNumber: node.loc?.start.line || 0,
      props: this.analyzeProps(node),
      state: [],
      hooks: this.extractHooks(node),
      renderComplexity,
      issues
    };
  }

  /**
   * Analyze an arrow function component
   */
  private analyzeArrowComponent(path: any, filePath: string): ComponentAnalysis {
    const node = path.node;
    const name = t.isIdentifier(node.id) ? node.id.name : 'Anonymous';
    const func = node.init;
    const issues: ComponentIssue[] = [];

    const renderComplexity = this.calculateRenderComplexity(func);
    if (renderComplexity > 10) {
      issues.push({
        type: 'component',
        severity: 'warning',
        message: `Component "${name}" has high render complexity (${renderComplexity})`,
        filePath,
        lineNumber: node.loc?.start.line || 0,
        componentName: name,
        suggestion: 'Consider breaking this component into smaller components'
      });
    }

    return {
      name,
      type: 'functional',
      filePath,
      lineNumber: node.loc?.start.line || 0,
      props: this.analyzeProps(func),
      state: [],
      hooks: this.extractHooks(func),
      renderComplexity,
      issues
    };
  }

  /**
   * Analyze a class component
   */
  private analyzeClassComponent(path: any, filePath: string): ComponentAnalysis {
    const node = path.node;
    const name = node.id?.name || 'Anonymous';
    const issues: ComponentIssue[] = [];

    // Class components are generally more complex
    issues.push({
      type: 'component',
      severity: 'info',
      message: `Consider converting class component "${name}" to functional component with hooks`,
      filePath,
      lineNumber: node.loc?.start.line || 0,
      componentName: name,
      suggestion: 'Functional components with hooks are generally preferred in modern React'
    });

    return {
      name,
      type: 'class',
      filePath,
      lineNumber: node.loc?.start.line || 0,
      props: [],
      state: this.analyzeClassState(node),
      hooks: [],
      renderComplexity: 5, // Base complexity for class components
      issues
    };
  }

  /**
   * Analyze a hook call
   */
  private analyzeHook(path: any, filePath: string): HookAnalysis {
    const node = path.node;
    const hookName = t.isIdentifier(node.callee) ? node.callee.name : 'unknown';
    const issues: HookIssue[] = [];

    // Analyze useEffect dependencies
    if (hookName === 'useEffect') {
      const depIssues = this.analyzeUseEffectDependencies(node, filePath);
      issues.push(...depIssues);
    }

    return {
      name: hookName,
      type: this.getHookType(hookName),
      filePath,
      lineNumber: node.loc?.start.line || 0,
      dependencies: this.extractDependencies(node),
      missingDependencies: [], // Will be populated by dependency analysis
      issues
    };
  }

  /**
   * Calculate render complexity based on JSX structure
   */
  private calculateRenderComplexity(node: t.Function): number {
    let complexity = 1;

    // Simple complexity calculation without traverse
    const calculateComplexityRecursive = (n: any): void => {
      if (!n || typeof n !== 'object') return;

      if (t.isJSXElement(n)) complexity++;
      if (t.isConditionalExpression(n)) complexity += 2;
      if (t.isLogicalExpression(n)) complexity += 2;
      if (t.isCallExpression(n) && t.isIdentifier(n.callee) && n.callee.name === 'map') {
        complexity += 3;
      }

      // Recursively check all properties
      Object.values(n).forEach(value => {
        if (Array.isArray(value)) {
          value.forEach(item => calculateComplexityRecursive(item));
        } else if (value && typeof value === 'object') {
          calculateComplexityRecursive(value);
        }
      });
    };

    calculateComplexityRecursive(node.body || node);
    return complexity;
  }

  /**
   * Analyze component props
   */
  private analyzeProps(node: t.Function): PropAnalysis[] {
    const props: PropAnalysis[] = [];
    
    if (node.params.length > 0) {
      const firstParam = node.params[0];
      if (t.isObjectPattern(firstParam)) {
        firstParam.properties.forEach(prop => {
          if (t.isObjectProperty(prop) && t.isIdentifier(prop.key)) {
            props.push({
              name: prop.key.name,
              type: 'unknown',
              required: true,
              drilling: false // Will be analyzed later
            });
          }
        });
      }
    }

    return props;
  }

  /**
   * Extract hooks used in a component
   */
  private extractHooks(node: t.Function): string[] {
    const hooks: string[] = [];

    // Simple hook extraction without traverse
    const extractHooksRecursive = (n: any): void => {
      if (!n || typeof n !== 'object') return;

      if (t.isCallExpression(n) && t.isIdentifier(n.callee) && this.isHookCall(n)) {
        hooks.push(n.callee.name);
      }

      // Recursively check all properties
      Object.values(n).forEach(value => {
        if (Array.isArray(value)) {
          value.forEach(item => extractHooksRecursive(item));
        } else if (value && typeof value === 'object') {
          extractHooksRecursive(value);
        }
      });
    };

    extractHooksRecursive(node.body || node);
    return hooks;
  }

  /**
   * Analyze class component state
   */
  private analyzeClassState(node: t.ClassDeclaration): StateAnalysis[] {
    // Simplified state analysis for class components
    return [];
  }

  /**
   * Get hook type category
   */
  private getHookType(hookName: string): string {
    if (hookName.startsWith('useState')) return 'state';
    if (hookName.startsWith('useEffect')) return 'effect';
    if (hookName.startsWith('useContext')) return 'context';
    if (hookName.startsWith('useReducer')) return 'state';
    if (hookName.startsWith('useMemo') || hookName.startsWith('useCallback')) return 'performance';
    return 'custom';
  }

  /**
   * Extract dependencies from hook calls
   */
  private extractDependencies(node: t.CallExpression): string[] {
    if (node.arguments.length > 1) {
      const depsArg = node.arguments[1];
      if (t.isArrayExpression(depsArg)) {
        return depsArg.elements
          .filter(el => t.isIdentifier(el))
          .map(el => (el as t.Identifier).name);
      }
    }
    return [];
  }

  /**
   * Analyze useEffect dependencies for missing deps
   */
  private analyzeUseEffectDependencies(node: t.CallExpression, filePath: string): HookIssue[] {
    const issues: HookIssue[] = [];
    
    // This is a simplified analysis - a full implementation would need
    // more sophisticated dependency tracking
    if (node.arguments.length === 1) {
      issues.push({
        type: 'hook',
        severity: 'warning',
        message: 'useEffect without dependency array may cause infinite re-renders',
        filePath,
        lineNumber: node.loc?.start.line || 0,
        hookName: 'useEffect',
        suggestion: 'Add dependency array as second argument'
      });
    }

    return issues;
  }

  /**
   * Analyze performance issues across all components
   */
  private analyzePerformanceIssues(result: ReactAnalysisResult): void {
    // Identify heavy components
    result.components.forEach(component => {
      if (component.renderComplexity > 15) {
        result.performance.heavyComponents.push(component.name);
        result.performance.optimizationOpportunities.push(
          `Consider memoizing ${component.name} with React.memo`
        );
      }
    });

    // Check for missing React.memo opportunities
    const functionalComponents = result.components.filter(c => c.type === 'functional');
    if (functionalComponents.length > 3) {
      result.performance.optimizationOpportunities.push(
        'Consider using React.memo for functional components that receive stable props'
      );
    }
  }
}
