/**
 * Logger - Simple logging utility with levels and formatting
 */

export type LogLevel = "debug" | "info" | "warn" | "error";

export class Logger {
  private component: string;
  private level: LogLevel;

  constructor(component: string, level: LogLevel = "info") {
    this.component = component;
    this.level = level;
  }

  debug(message: string, ...args: any[]): void {
    if (this.shouldLog("debug")) {
      this.log("debug", message, ...args);
    }
  }

  info(message: string, ...args: any[]): void {
    if (this.shouldLog("info")) {
      this.log("info", message, ...args);
    }
  }

  warn(message: string, ...args: any[]): void {
    if (this.shouldLog("warn")) {
      this.log("warn", message, ...args);
    }
  }

  error(message: string, ...args: any[]): void {
    if (this.shouldLog("error")) {
      this.log("error", message, ...args);
    }
  }

  private shouldLog(level: LogLevel): boolean {
    const levels = ["debug", "info", "warn", "error"];
    return levels.indexOf(level) >= levels.indexOf(this.level);
  }

  private log(level: LogLevel, message: string, ...args: any[]): void {
    const timestamp = new Date().toISOString();
    const prefix = `[${timestamp}] [${level.toUpperCase()}] [${this.component}]`;

    // Use console.error for all levels to avoid stdout interference with MCP protocol
    console.error(prefix, message, ...args);
  }

  setLevel(level: LogLevel): void {
    this.level = level;
  }
}
