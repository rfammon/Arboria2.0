/**
 * ChromeDebugger - Chrome DevTools Protocol integration
 * 
 * Handles:
 * - Browser connection via Puppeteer
 * - Error capture from browser console
 * - Network monitoring
 * - Performance profiling
 * - Breakpoint management
 */

import { EventEmitter } from "events";
import puppeteer, { Browser, Page, CDPSession } from "puppeteer";
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { ErrorInfo } from "../core/DebuggerCore.js";

// Variable inspection interfaces
export interface VariableDescriptor {
  name: string;
  value: any;
  type: string;
  subtype?: string;
  description: string;
  objectId?: string;
  writable: boolean;
  configurable: boolean;
  enumerable: boolean;
  isOwn: boolean;
  preview?: any;
}

export interface ScopeDescriptor {
  type: 'global' | 'local' | 'with' | 'closure' | 'catch' | 'block' | 'script' | 'eval' | 'module' | 'wasm-expression-stack';
  name?: string;
  startLocation?: any;
  endLocation?: any;
  objectId: string;
  variableCount: number;
  variables?: VariableDescriptor[];
}

export interface EvaluationResult {
  result: any;
  type: string;
  description: string;
  objectId?: string;
  exceptionDetails?: any;
  wasThrown: boolean;
}

export interface CallFrameInfo {
  callFrameId: string;
  functionName: string;
  location: any;
  url: string;
  scopeChain: ScopeDescriptor[];
  thisObject: any;
}

// Breakpoint-related interfaces
export interface BreakpointLocation {
  url?: string;
  filePath?: string;
  lineNumber: number;
  columnNumber?: number;
}

export interface BreakpointOptions {
  condition?: string;
  logMessage?: string;
  hitCountCondition?: string;
  enabled?: boolean;
}

export interface BreakpointInfo {
  id: string;
  location: BreakpointLocation;
  options: BreakpointOptions;
  hitCount: number;
  enabled: boolean;
  timestamp: Date;
}

export interface BreakpointHit {
  breakpointId: string;
  timestamp: Date;
  callFrames: any[];
  reason: string;
  data?: any;
}

export class ChromeDebugger extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private browser: Browser | null = null;
  private page: Page | null = null;
  private cdpSession: CDPSession | null = null;
  private isConnected = false;
  private breakpoints: Map<string, BreakpointInfo> = new Map();
  private debuggerEnabled = false;
  private currentCallFrames: CallFrameInfo[] = [];
  private isPaused = false;

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("ChromeDebugger");
    this.configManager = configManager;
  }

  /**
   * Initialize Chrome debugger connection
   */
  async initialize(): Promise<void> {
    try {
      this.logger.info("Initializing Chrome debugger...");
      
      const config = this.configManager.getConfig();
      
      if (!config.browser.autoConnect) {
        this.logger.info("Auto-connect disabled, skipping Chrome connection");
        return;
      }

      await this.connect();
      
      this.logger.info("Chrome debugger initialized successfully");
    } catch (error) {
      this.logger.error("Failed to initialize Chrome debugger:", error);
      throw error;
    }
  }

  /**
   * Connect to Chrome browser
   */
  async connect(): Promise<void> {
    try {
      const config = this.configManager.getConfig();
      
      // Try to connect to existing browser first
      try {
        this.browser = await puppeteer.connect({
          browserURL: `http://${config.browser.host}:${config.browser.port}`,
          defaultViewport: null
        });
        this.logger.info("Connected to existing Chrome instance");
      } catch (error) {
        // Launch new browser if connection fails
        this.logger.info("Launching new Chrome instance...");
        this.browser = await puppeteer.launch({
          headless: false, // For debugging
          devtools: true,
          args: [
            `--remote-debugging-port=${config.browser.port}`,
            '--disable-web-security',
            '--disable-features=VizDisplayCompositor'
          ]
        });
      }

      // Get or create a page
      const pages = await this.browser.pages();
      this.page = pages[0] || await this.browser.newPage();

      // Get CDP session for advanced debugging features
      this.cdpSession = await this.page.createCDPSession();

      // Enable Debugger domain for breakpoint support
      await this.enableDebugger();

      // Setup event listeners
      this.setupEventListeners();

      this.isConnected = true;
      this.emit("connected");
      
    } catch (error) {
      this.logger.error("Failed to connect to Chrome:", error);
      throw error;
    }
  }

  /**
   * Enable Chrome DevTools Debugger domain
   */
  private async enableDebugger(): Promise<void> {
    if (!this.cdpSession) return;

    try {
      await this.cdpSession.send('Debugger.enable');
      await this.cdpSession.send('Runtime.enable');
      this.debuggerEnabled = true;
      this.logger.info("Chrome Debugger domain enabled");

      // Set up debugger event listeners
      this.cdpSession.on('Debugger.paused', (params: any) => {
        this.handleBreakpointHit(params);
      });

      this.cdpSession.on('Debugger.resumed', () => {
        this.isPaused = false;
        this.currentCallFrames = [];
        this.emit('debuggerResumed');
      });

    } catch (error) {
      this.logger.error("Failed to enable Debugger domain:", error);
      throw error;
    }
  }

  /**
   * Handle breakpoint hit events
   */
  private handleBreakpointHit(params: any): void {
    const { callFrames, reason, hitBreakpoints } = params;

    // Store call frames for variable inspection
    this.updateCallFrames(callFrames);
    this.isPaused = true;

    if (hitBreakpoints && hitBreakpoints.length > 0) {
      for (const breakpointId of hitBreakpoints) {
        const breakpoint = this.breakpoints.get(breakpointId);
        if (breakpoint) {
          breakpoint.hitCount++;

          const hit: BreakpointHit = {
            breakpointId,
            timestamp: new Date(),
            callFrames,
            reason,
            data: params
          };

          // Handle logpoints
          if (breakpoint.options.logMessage) {
            this.handleLogpoint(breakpoint, hit);
          }

          this.emit('breakpointHit', hit);
          this.logger.info(`Breakpoint hit: ${breakpointId} (${breakpoint.hitCount} times)`);
        }
      }
    }

    // Emit paused event for variable inspection
    this.emit('debuggerPaused', { callFrames, reason });
  }

  /**
   * Update stored call frames from debugger paused event
   */
  private updateCallFrames(callFrames: any[]): void {
    this.currentCallFrames = callFrames.map((frame: any) => ({
      callFrameId: frame.callFrameId,
      functionName: frame.functionName,
      location: frame.location,
      url: frame.url,
      scopeChain: frame.scopeChain.map((scope: any) => ({
        type: scope.type,
        name: scope.name,
        startLocation: scope.startLocation,
        endLocation: scope.endLocation,
        objectId: scope.object.objectId,
        variableCount: 0 // Will be populated when variables are requested
      })),
      thisObject: frame.this
    }));

    this.logger.info(`Updated call frames: ${this.currentCallFrames.length} frames available`);
  }

  /**
   * Handle logpoint execution
   */
  private async handleLogpoint(breakpoint: BreakpointInfo, hit: BreakpointHit): Promise<void> {
    if (!this.cdpSession || !breakpoint.options.logMessage) return;

    try {
      // Evaluate the log message in the current context
      await this.cdpSession.send('Runtime.evaluate', {
        expression: `console.log(${JSON.stringify(breakpoint.options.logMessage)})`,
        contextId: hit.callFrames[0]?.callFrameId
      });

      this.logger.info(`Logpoint executed: ${breakpoint.options.logMessage}`);
    } catch (error) {
      this.logger.error("Failed to execute logpoint:", error);
    }
  }

  /**
   * Setup event listeners for browser events
   */
  private setupEventListeners(): void {
    if (!this.page) return;

    // Console events
    this.page.on('console', (msg) => {
      const error: ErrorInfo = {
        id: this.generateId(),
        timestamp: new Date(),
        type: "console",
        severity: this.mapConsoleSeverity(msg.type()),
        message: msg.text(),
        source: "browser",
        context: {
          type: msg.type(),
          location: msg.location()
        }
      };
      this.emit("error", error);
    });

    // Page errors
    this.page.on('pageerror', (error) => {
      const errorInfo: ErrorInfo = {
        id: this.generateId(),
        timestamp: new Date(),
        type: "javascript",
        severity: "error",
        message: error.message,
        stack: error.stack,
        source: "browser"
      };
      this.emit("error", errorInfo);
    });

    // Request failures
    this.page.on('requestfailed', (request) => {
      const failure = request.failure();
      if (failure) {
        const error: ErrorInfo = {
          id: this.generateId(),
          timestamp: new Date(),
          type: "network",
          severity: "error",
          message: `Network request failed: ${failure.errorText}`,
          source: "browser",
          context: {
            url: request.url(),
            method: request.method(),
            errorText: failure.errorText
          }
        };
        this.emit("error", error);
      }
    });

    // Browser disconnect
    this.browser?.on('disconnected', () => {
      this.isConnected = false;
      this.emit("disconnected");
      this.logger.warn("Browser disconnected");
    });
  }

  /**
   * Map console message type to severity
   */
  private mapConsoleSeverity(type: string): "error" | "warning" | "info" {
    switch (type) {
      case "error":
        return "error";
      case "warning":
      case "warn":
        return "warning";
      default:
        return "info";
    }
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return `chrome-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
  }

  /**
   * Check if connected to browser
   */
  isConnectedToBrowser(): boolean {
    return this.isConnected && this.browser !== null;
  }

  /**
   * Check if debugger is enabled
   */
  isDebuggerEnabled(): boolean {
    return this.debuggerEnabled && this.cdpSession !== null;
  }

  // ===== BREAKPOINT MANAGEMENT METHODS =====

  /**
   * Set a breakpoint by URL and line number
   */
  async setBreakpoint(location: BreakpointLocation, options: BreakpointOptions = {}): Promise<BreakpointInfo> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot set breakpoint.");
    }

    try {
      const breakpointId = this.generateBreakpointId();

      // Prepare CDP parameters
      const params: any = {
        lineNumber: location.lineNumber - 1, // CDP uses 0-based line numbers
      };

      if (location.columnNumber !== undefined) {
        params.columnNumber = location.columnNumber;
      }

      if (options.condition) {
        params.condition = options.condition;
      }

      let cdpResult: any;

      // Set breakpoint by URL or script ID
      if (location.url) {
        cdpResult = await this.cdpSession.send('Debugger.setBreakpointByUrl', {
          ...params,
          url: location.url
        });
      } else if (location.filePath) {
        // Convert file path to URL if possible
        const url = this.filePathToUrl(location.filePath);
        cdpResult = await this.cdpSession.send('Debugger.setBreakpointByUrl', {
          ...params,
          url
        });
      } else {
        throw new Error("Either URL or filePath must be provided for breakpoint location");
      }

      // Create breakpoint info
      const breakpointInfo: BreakpointInfo = {
        id: breakpointId,
        location: {
          ...location,
          lineNumber: cdpResult.actualLocation?.lineNumber + 1 || location.lineNumber, // Convert back to 1-based
          columnNumber: cdpResult.actualLocation?.columnNumber || location.columnNumber
        },
        options: {
          enabled: true,
          ...options
        },
        hitCount: 0,
        enabled: true,
        timestamp: new Date()
      };

      // Store breakpoint
      this.breakpoints.set(cdpResult.breakpointId, breakpointInfo);

      this.logger.info(`Breakpoint set: ${breakpointId} at ${location.filePath || location.url}:${location.lineNumber}`);
      this.emit('breakpointSet', breakpointInfo);

      return breakpointInfo;

    } catch (error) {
      this.logger.error("Failed to set breakpoint:", error);
      throw error;
    }
  }

  /**
   * Remove a breakpoint by ID
   */
  async removeBreakpoint(breakpointId: string): Promise<boolean> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot remove breakpoint.");
    }

    try {
      const breakpoint = this.breakpoints.get(breakpointId);
      if (!breakpoint) {
        this.logger.warn(`Breakpoint not found: ${breakpointId}`);
        return false;
      }

      await this.cdpSession.send('Debugger.removeBreakpoint', {
        breakpointId
      });

      this.breakpoints.delete(breakpointId);

      this.logger.info(`Breakpoint removed: ${breakpointId}`);
      this.emit('breakpointRemoved', breakpoint);

      return true;

    } catch (error) {
      this.logger.error("Failed to remove breakpoint:", error);
      throw error;
    }
  }

  /**
   * Get all active breakpoints
   */
  getBreakpoints(): BreakpointInfo[] {
    return Array.from(this.breakpoints.values());
  }

  /**
   * Get a specific breakpoint by ID
   */
  getBreakpoint(breakpointId: string): BreakpointInfo | undefined {
    return this.breakpoints.get(breakpointId);
  }

  /**
   * Enable or disable all breakpoints
   */
  async setBreakpointsActive(active: boolean): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot toggle breakpoints.");
    }

    try {
      await this.cdpSession.send('Debugger.setBreakpointsActive', { active });

      // Update local state
      for (const breakpoint of this.breakpoints.values()) {
        breakpoint.enabled = active;
      }

      this.logger.info(`Breakpoints ${active ? 'enabled' : 'disabled'}`);
      this.emit('breakpointsToggled', active);

    } catch (error) {
      this.logger.error("Failed to toggle breakpoints:", error);
      throw error;
    }
  }

  /**
   * Clear all breakpoints
   */
  async clearAllBreakpoints(): Promise<void> {
    const breakpointIds = Array.from(this.breakpoints.keys());

    for (const id of breakpointIds) {
      try {
        await this.removeBreakpoint(id);
      } catch (error) {
        this.logger.error(`Failed to remove breakpoint ${id}:`, error);
      }
    }

    this.logger.info("All breakpoints cleared");
  }

  // ===== UTILITY METHODS =====

  /**
   * Generate unique breakpoint ID
   */
  private generateBreakpointId(): string {
    return `bp-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
  }

  /**
   * Convert file path to URL for CDP
   */
  private filePathToUrl(filePath: string): string {
    // Simple conversion - in a real implementation, this would need to be more sophisticated
    // to handle different project structures and serve URLs
    if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
      return filePath;
    }

    // For local development, assume files are served from localhost
    const normalizedPath = filePath.replace(/\\/g, '/');
    if (normalizedPath.startsWith('/')) {
      return `http://localhost:3000${normalizedPath}`;
    } else {
      return `http://localhost:3000/${normalizedPath}`;
    }
  }

  /**
   * Resume execution after hitting a breakpoint
   */
  async resume(): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot resume execution.");
    }

    try {
      await this.cdpSession.send('Debugger.resume');
      this.logger.info("Execution resumed");
      this.emit('executionResumed');
    } catch (error) {
      this.logger.error("Failed to resume execution:", error);
      throw error;
    }
  }

  /**
   * Step over to the next line
   */
  async stepOver(): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot step over.");
    }

    try {
      await this.cdpSession.send('Debugger.stepOver');
      this.logger.info("Stepped over");
      this.emit('stepOver');
    } catch (error) {
      this.logger.error("Failed to step over:", error);
      throw error;
    }
  }

  /**
   * Step into function
   */
  async stepInto(): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot step into.");
    }

    try {
      await this.cdpSession.send('Debugger.stepInto');
      this.logger.info("Stepped into");
      this.emit('stepInto');
    } catch (error) {
      this.logger.error("Failed to step into:", error);
      throw error;
    }
  }

  /**
   * Step out of current function
   */
  async stepOut(): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot step out.");
    }

    try {
      await this.cdpSession.send('Debugger.stepOut');
      this.logger.info("Stepped out");
      this.emit('stepOut');
    } catch (error) {
      this.logger.error("Failed to step out:", error);
      throw error;
    }
  }

  // ============================================================================
  // Variable Inspection Methods
  // ============================================================================

  /**
   * Get current call frames when debugger is paused
   */
  async getCallFrames(): Promise<CallFrameInfo[]> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot get call frames.");
    }

    if (!this.isPaused) {
      this.logger.warn("Debugger is not paused. No call frames available.");
      return [];
    }

    return this.currentCallFrames;
  }

  /**
   * Get scope chain for a specific call frame
   */
  async getScopeChain(callFrameId: string): Promise<ScopeDescriptor[]> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot get scope chain.");
    }

    if (!this.isPaused) {
      throw new Error("Debugger is not paused. Cannot get scope chain.");
    }

    try {
      const callFrame = this.currentCallFrames.find(frame => frame.callFrameId === callFrameId);
      if (!callFrame) {
        throw new Error(`Call frame not found: ${callFrameId}`);
      }

      this.logger.info(`Getting scope chain for call frame: ${callFrameId}`);
      return callFrame.scopeChain;
    } catch (error) {
      this.logger.error("Failed to get scope chain:", error);
      throw error;
    }
  }

  /**
   * Get variables in a specific scope
   */
  async getVariablesInScope(objectId: string, includeNonEnumerable: boolean = false): Promise<VariableDescriptor[]> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot get variables.");
    }

    try {
      const result = await this.cdpSession.send('Runtime.getProperties', {
        objectId,
        ownProperties: true,
        accessorPropertiesOnly: false,
        generatePreview: true,
        nonIndexedPropertiesOnly: !includeNonEnumerable
      });

      const variables: VariableDescriptor[] = [];

      if (result.result) {
        for (const prop of result.result) {
          const variable: VariableDescriptor = {
            name: prop.name,
            value: prop.value?.value,
            type: prop.value?.type || 'undefined',
            subtype: prop.value?.subtype,
            description: prop.value?.description || '',
            objectId: prop.value?.objectId,
            writable: prop.writable || false,
            configurable: prop.configurable || false,
            enumerable: prop.enumerable || false,
            isOwn: prop.isOwn || false,
            preview: prop.value?.preview
          };
          variables.push(variable);
        }
      }

      this.logger.info(`Retrieved ${variables.length} variables from scope`);
      return variables;

    } catch (error) {
      this.logger.error("Failed to get variables in scope:", error);
      throw error;
    }
  }

  /**
   * Evaluate expression in call frame context
   */
  async evaluateOnCallFrame(
    callFrameId: string,
    expression: string,
    options: {
      includeCommandLineAPI?: boolean;
      returnByValue?: boolean;
      throwOnSideEffect?: boolean;
      timeout?: number;
    } = {}
  ): Promise<EvaluationResult> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot evaluate expression.");
    }

    try {
      const result = await this.cdpSession.send('Debugger.evaluateOnCallFrame', {
        callFrameId,
        expression,
        objectGroup: 'variable-inspection',
        includeCommandLineAPI: options.includeCommandLineAPI || false,
        silent: false,
        returnByValue: options.returnByValue || false,
        generatePreview: true,
        throwOnSideEffect: options.throwOnSideEffect || false,
        timeout: options.timeout
      });

      const evaluationResult: EvaluationResult = {
        result: result.result?.value,
        type: result.result?.type || 'undefined',
        description: result.result?.description || '',
        objectId: result.result?.objectId,
        exceptionDetails: result.exceptionDetails,
        wasThrown: !!result.exceptionDetails
      };

      this.logger.info(`Evaluated expression: ${expression}`);
      return evaluationResult;

    } catch (error) {
      this.logger.error("Failed to evaluate expression on call frame:", error);
      throw error;
    }
  }

  /**
   * Evaluate expression in global context
   */
  async evaluateExpression(
    expression: string,
    options: {
      includeCommandLineAPI?: boolean;
      returnByValue?: boolean;
      throwOnSideEffect?: boolean;
      timeout?: number;
    } = {}
  ): Promise<EvaluationResult> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot evaluate expression.");
    }

    try {
      const result = await this.cdpSession.send('Runtime.evaluate', {
        expression,
        objectGroup: 'variable-inspection',
        includeCommandLineAPI: options.includeCommandLineAPI || false,
        silent: false,
        returnByValue: options.returnByValue || false,
        generatePreview: true,
        awaitPromise: false,
        throwOnSideEffect: options.throwOnSideEffect || false,
        timeout: options.timeout
      });

      const evaluationResult: EvaluationResult = {
        result: result.result?.value,
        type: result.result?.type || 'undefined',
        description: result.result?.description || '',
        objectId: result.result?.objectId,
        exceptionDetails: result.exceptionDetails,
        wasThrown: !!result.exceptionDetails
      };

      this.logger.info(`Evaluated expression: ${expression}`);
      return evaluationResult;

    } catch (error) {
      this.logger.error("Failed to evaluate expression:", error);
      throw error;
    }
  }

  /**
   * Get current paused state
   */
  isPausedState(): boolean {
    return this.isPaused;
  }

  /**
   * Get top call frame (most recent in stack)
   */
  getTopCallFrame(): CallFrameInfo | null {
    return this.currentCallFrames.length > 0 ? this.currentCallFrames[0] || null : null;
  }

  /**
   * Get call frame by ID
   */
  getCallFrameById(callFrameId: string): CallFrameInfo | null {
    return this.currentCallFrames.find(frame => frame.callFrameId === callFrameId) || null;
  }

  /**
   * Modify variable value in a specific scope
   */
  async setVariableValue(
    callFrameId: string,
    scopeNumber: number,
    variableName: string,
    newValue: any
  ): Promise<void> {
    if (!this.cdpSession || !this.debuggerEnabled) {
      throw new Error("Debugger not enabled. Cannot set variable value.");
    }

    try {
      // Convert the new value to a CallArgument format
      const callArgument = {
        value: newValue
      };

      await this.cdpSession.send('Debugger.setVariableValue', {
        scopeNumber,
        variableName,
        newValue: callArgument,
        callFrameId
      });

      this.logger.info(`Set variable ${variableName} to new value in scope ${scopeNumber}`);

    } catch (error) {
      this.logger.error("Failed to set variable value:", error);
      throw error;
    }
  }

  /**
   * Enable HeapProfiler domain for memory analysis
   */
  private async enableHeapProfiler(): Promise<void> {
    if (!this.cdpSession) return;

    try {
      await this.cdpSession.send('HeapProfiler.enable');
      this.logger.info("HeapProfiler domain enabled");
    } catch (error) {
      this.logger.error("Failed to enable HeapProfiler domain:", error);
      throw error;
    }
  }

  /**
   * Take heap snapshot for memory analysis
   */
  async takeHeapSnapshot(): Promise<any> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot take heap snapshot.");
    }

    try {
      // Enable HeapProfiler if not already enabled
      await this.enableHeapProfiler();

      // Take heap snapshot
      const snapshot = await this.cdpSession.send('HeapProfiler.takeHeapSnapshot', {
        reportProgress: false
      });

      this.logger.info("Heap snapshot taken successfully");
      return snapshot;

    } catch (error) {
      this.logger.error("Failed to take heap snapshot:", error);
      throw error;
    }
  }

  /**
   * Start heap sampling for memory profiling
   */
  async startHeapSampling(samplingInterval: number = 32768): Promise<void> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot start heap sampling.");
    }

    try {
      await this.enableHeapProfiler();

      await this.cdpSession.send('HeapProfiler.startSampling', {
        samplingInterval
      });

      this.logger.info(`Heap sampling started with interval: ${samplingInterval}`);

    } catch (error) {
      this.logger.error("Failed to start heap sampling:", error);
      throw error;
    }
  }

  /**
   * Stop heap sampling and get profile
   */
  async stopHeapSampling(): Promise<any> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot stop heap sampling.");
    }

    try {
      const profile = await this.cdpSession.send('HeapProfiler.stopSampling');
      this.logger.info("Heap sampling stopped and profile collected");
      return profile;

    } catch (error) {
      this.logger.error("Failed to stop heap sampling:", error);
      throw error;
    }
  }

  /**
   * Get heap usage statistics
   */
  async getHeapUsage(): Promise<any> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot get heap usage.");
    }

    try {
      const usage = await this.cdpSession.send('Runtime.getHeapUsage');
      this.logger.debug("Heap usage retrieved", usage);
      return usage;

    } catch (error) {
      this.logger.error("Failed to get heap usage:", error);
      throw error;
    }
  }

  /**
   * Collect garbage to free memory
   */
  async collectGarbage(): Promise<void> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot collect garbage.");
    }

    try {
      // Use HeapProfiler.collectGarbage instead
      await this.enableHeapProfiler();
      await this.cdpSession.send('HeapProfiler.collectGarbage' as any);
      this.logger.info("Garbage collection triggered");

    } catch (error) {
      this.logger.warn("Failed to trigger garbage collection via HeapProfiler:", error);
      // Try alternative approach
      try {
        await this.cdpSession.send('Runtime.evaluate', {
          expression: 'if (window.gc) window.gc();'
        });
        this.logger.info("Garbage collection triggered via Runtime.evaluate");
      } catch (evalError) {
        this.logger.error("Failed to trigger garbage collection:", evalError);
        throw evalError;
      }
    }
  }

  /**
   * Enable Network domain for network monitoring
   */
  private async enableNetwork(): Promise<void> {
    if (!this.cdpSession) return;

    try {
      await this.cdpSession.send('Network.enable');
      this.logger.info("Network domain enabled");

      // Set up network event listeners
      this.setupNetworkEventListeners();

    } catch (error) {
      this.logger.error("Failed to enable Network domain:", error);
      throw error;
    }
  }

  /**
   * Set up network event listeners
   */
  private setupNetworkEventListeners(): void {
    if (!this.cdpSession) return;

    // Track network requests
    const requestMap = new Map<string, any>();

    this.cdpSession.on('Network.requestWillBeSent', (params: any) => {
      requestMap.set(params.requestId, {
        ...params,
        startTime: Date.now()
      });
    });

    this.cdpSession.on('Network.responseReceived', (params: any) => {
      const request = requestMap.get(params.requestId);
      if (request) {
        request.response = params.response;
        request.responseTime = Date.now();
      }
    });

    this.cdpSession.on('Network.loadingFinished', (params: any) => {
      const request = requestMap.get(params.requestId);
      if (request) {
        const networkMetric = {
          requestId: params.requestId,
          url: request.request.url,
          method: request.request.method,
          startTime: request.startTime,
          endTime: Date.now(),
          duration: Date.now() - request.startTime,
          responseSize: params.encodedDataLength || 0,
          requestSize: request.request.postDataSize || 0,
          statusCode: request.response?.status || 0,
          timing: this.calculateNetworkTiming(request, params)
        };

        this.emit('networkMetric', networkMetric);
        requestMap.delete(params.requestId);
      }
    });

    this.cdpSession.on('Network.loadingFailed', (params: any) => {
      const request = requestMap.get(params.requestId);
      if (request) {
        this.emit('networkError', {
          requestId: params.requestId,
          url: request.request.url,
          method: request.request.method,
          errorText: params.errorText,
          timestamp: Date.now()
        });
        requestMap.delete(params.requestId);
      }
    });
  }

  /**
   * Calculate detailed network timing
   */
  private calculateNetworkTiming(request: any, params: any): any {
    const timing = request.response?.timing;
    if (!timing) {
      return {
        dnsLookup: 0,
        tcpConnect: 0,
        tlsHandshake: 0,
        requestSent: 0,
        waiting: 0,
        contentDownload: 0
      };
    }

    return {
      dnsLookup: timing.dnsEnd - timing.dnsStart,
      tcpConnect: timing.connectEnd - timing.connectStart,
      tlsHandshake: timing.sslEnd > 0 ? timing.sslEnd - timing.sslStart : 0,
      requestSent: timing.sendEnd - timing.sendStart,
      waiting: timing.receiveHeadersEnd - timing.sendEnd,
      contentDownload: params.timestamp - timing.receiveHeadersEnd
    };
  }

  /**
   * Get network metrics for a specific timeframe
   */
  async getNetworkMetrics(timeframe: number = 60000): Promise<any[]> {
    // This would require storing network metrics
    // For now, return empty array
    return [];
  }

  /**
   * Clear browser cache
   */
  async clearBrowserCache(): Promise<void> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot clear cache.");
    }

    try {
      await this.enableNetwork();
      await this.cdpSession.send('Network.clearBrowserCache');
      this.logger.info("Browser cache cleared");
    } catch (error) {
      this.logger.error("Failed to clear browser cache:", error);
      throw error;
    }
  }

  /**
   * Clear browser cookies
   */
  async clearBrowserCookies(): Promise<void> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot clear cookies.");
    }

    try {
      await this.enableNetwork();
      await this.cdpSession.send('Network.clearBrowserCookies');
      this.logger.info("Browser cookies cleared");
    } catch (error) {
      this.logger.error("Failed to clear browser cookies:", error);
      throw error;
    }
  }

  /**
   * Set network throttling
   */
  async setNetworkThrottling(options: {
    offline?: boolean;
    downloadThroughput?: number;
    uploadThroughput?: number;
    latency?: number;
  }): Promise<void> {
    if (!this.cdpSession) {
      throw new Error("Chrome debugger not connected. Cannot set network throttling.");
    }

    try {
      await this.enableNetwork();
      await this.cdpSession.send('Network.emulateNetworkConditions', {
        offline: options.offline || false,
        downloadThroughput: options.downloadThroughput || -1,
        uploadThroughput: options.uploadThroughput || -1,
        latency: options.latency || 0
      });
      this.logger.info("Network throttling configured", options);
    } catch (error) {
      this.logger.error("Failed to set network throttling:", error);
      throw error;
    }
  }

  /**
   * Shutdown Chrome debugger
   */
  async shutdown(): Promise<void> {
    try {
      this.logger.info("Shutting down Chrome debugger...");

      // Clear all breakpoints before shutdown
      if (this.debuggerEnabled) {
        await this.clearAllBreakpoints();
      }

      // Disable debugger domain
      if (this.cdpSession && this.debuggerEnabled) {
        try {
          await this.cdpSession.send('Debugger.disable');
          await this.cdpSession.send('Runtime.disable');
        } catch (error) {
          this.logger.warn("Error disabling debugger domain:", error);
        }
      }

      // Disconnect CDP session
      if (this.cdpSession) {
        await this.cdpSession.detach();
        this.cdpSession = null;
      }

      if (this.browser) {
        await this.browser.disconnect();
        this.browser = null;
      }

      this.page = null;
      this.isConnected = false;
      this.debuggerEnabled = false;
      this.breakpoints.clear();

      this.logger.info("Chrome debugger shutdown complete");
    } catch (error) {
      this.logger.error("Error during Chrome debugger shutdown:", error);
      throw error;
    }
  }
}
