/**
 * AIErrorAnalyzer - AI-powered error analysis and categorization
 * 
 * Uses Vercel AI SDK to provide intelligent error analysis including:
 * - Automatic error categorization using OpenAI/Anthropic models
 * - Pattern recognition across debugging sessions
 * - Error frequency analysis and trend detection
 * - Context-aware error grouping and deduplication
 */

import { EventEmitter } from "events";
import { generateObject, generateText } from "ai";
import { openai } from "@ai-sdk/openai";
import { z } from "zod";
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { ErrorInfo } from "../core/DebuggerCore.js";

// Zod schemas for structured AI outputs
const ErrorCategorySchema = z.object({
  category: z.enum([
    "syntax_error",
    "type_error", 
    "reference_error",
    "network_error",
    "performance_issue",
    "react_error",
    "state_management",
    "async_error",
    "security_issue",
    "configuration_error",
    "unknown"
  ]).describe("Primary error category"),
  subcategory: z.string().describe("More specific error classification"),
  severity: z.enum(["critical", "high", "medium", "low"]).describe("Error severity level"),
  confidence: z.number().min(0).max(1).describe("Confidence score for categorization"),
  reasoning: z.string().describe("Explanation of why this categorization was chosen")
});

const ErrorPatternSchema = z.object({
  patterns: z.array(z.object({
    pattern: z.string().describe("Identified error pattern"),
    frequency: z.number().describe("How often this pattern occurs"),
    impact: z.enum(["high", "medium", "low"]).describe("Impact level of this pattern"),
    suggestion: z.string().describe("Suggested fix or improvement")
  })),
  trends: z.array(z.object({
    trend: z.string().describe("Identified trend in errors"),
    direction: z.enum(["increasing", "decreasing", "stable"]).describe("Trend direction"),
    timeframe: z.string().describe("Time period for this trend"),
    recommendation: z.string().describe("Recommended action based on trend")
  }))
});

const ErrorGroupingSchema = z.object({
  groups: z.array(z.object({
    groupId: z.string().describe("Unique identifier for error group"),
    title: z.string().describe("Human-readable title for the group"),
    description: z.string().describe("Description of what errors in this group have in common"),
    errorIds: z.array(z.string()).describe("List of error IDs that belong to this group"),
    rootCause: z.string().describe("Likely root cause of errors in this group"),
    priority: z.enum(["critical", "high", "medium", "low"]).describe("Priority for fixing this group"),
    estimatedEffort: z.string().describe("Estimated effort to fix this group of errors")
  })),
  duplicates: z.array(z.object({
    primaryErrorId: z.string().describe("ID of the primary error"),
    duplicateErrorIds: z.array(z.string()).describe("IDs of duplicate errors"),
    similarity: z.number().min(0).max(1).describe("Similarity score between errors")
  }))
});

export interface ErrorAnalysis {
  errorId: string;
  timestamp: Date;
  category: string;
  subcategory: string;
  severity: "critical" | "high" | "medium" | "low";
  confidence: number;
  reasoning: string;
  suggestions: string[];
  relatedErrors: string[];
  tags: string[];
}

export interface ErrorPattern {
  pattern: string;
  frequency: number;
  impact: "high" | "medium" | "low";
  suggestion: string;
  firstSeen: Date;
  lastSeen: Date;
  affectedFiles: string[];
}

export interface ErrorTrend {
  trend: string;
  direction: "increasing" | "decreasing" | "stable";
  timeframe: string;
  recommendation: string;
  dataPoints: Array<{ timestamp: Date; count: number }>;
}

export interface ErrorGroup {
  groupId: string;
  title: string;
  description: string;
  errorIds: string[];
  rootCause: string;
  priority: "critical" | "high" | "medium" | "low";
  estimatedEffort: string;
  createdAt: Date;
  updatedAt: Date;
}

export class AIErrorAnalyzer extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private errorAnalyses: Map<string, ErrorAnalysis> = new Map();
  private errorPatterns: ErrorPattern[] = [];
  private errorTrends: ErrorTrend[] = [];
  private errorGroups: ErrorGroup[] = [];
  private aiModel: any;

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("AIErrorAnalyzer");
    this.configManager = configManager;
    
    // Initialize AI model based on configuration
    const config = this.configManager.getConfig();

    // Check if AI is enabled and API key is available
    if (config.ai?.enabled && (config.ai?.apiKey || process.env.OPENAI_API_KEY)) {
      this.aiModel = openai(config.ai?.model || 'gpt-4o-mini');
    } else {
      this.logger.warn("AI features disabled: No API key provided or AI disabled in config");
      this.aiModel = null;
    }
  }

  async initialize(): Promise<void> {
    this.logger.info("AIErrorAnalyzer initialized with AI-powered analysis");
  }

  /**
   * Analyze a single error using AI
   */
  async analyzeError(error: ErrorInfo): Promise<ErrorAnalysis> {
    try {
      this.logger.debug(`Analyzing error with AI: ${error.message}`);

      // Check if AI is available
      if (!this.aiModel) {
        return this.createFallbackAnalysis(error);
      }

      // Prepare context for AI analysis
      const context = this.prepareErrorContext(error);

      // Use AI to categorize and analyze the error
      const { object: categorization } = await generateObject({
        model: this.aiModel,
        schema: ErrorCategorySchema,
        prompt: `Analyze this JavaScript/TypeScript error and categorize it:

Error Details:
- Message: ${error.message}
- Type: ${error.type}
- Stack Trace: ${error.stack}
- File: ${error.file || 'unknown'}
- Line: ${error.line || 'unknown'}
- Context: ${context}

Please categorize this error and provide reasoning for your classification.`,
      });

      // Generate suggestions using AI
      const { text: suggestions } = await generateText({
        model: this.aiModel,
        prompt: `Based on this error analysis, provide 3-5 specific, actionable suggestions to fix or prevent this error:

Error: ${error.message}
Category: ${categorization.category}
Subcategory: ${categorization.subcategory}
Context: ${context}

Provide practical, code-specific suggestions that a developer can immediately act upon.`,
      });

      const analysis: ErrorAnalysis = {
        errorId: error.id,
        timestamp: new Date(),
        category: categorization.category,
        subcategory: categorization.subcategory,
        severity: categorization.severity,
        confidence: categorization.confidence,
        reasoning: categorization.reasoning,
        suggestions: suggestions.split('\n').filter(s => s.trim().length > 0),
        relatedErrors: await this.findRelatedErrors(error),
        tags: this.generateTags(error, categorization)
      };

      this.errorAnalyses.set(error.id, analysis);
      this.emit('errorAnalyzed', analysis);

      this.logger.info(`Error analyzed: ${categorization.category}/${categorization.subcategory} (confidence: ${categorization.confidence})`);
      return analysis;

    } catch (error) {
      this.logger.error("Failed to analyze error with AI:", error);
      throw error;
    }
  }

  /**
   * Detect patterns across multiple errors using AI
   */
  async detectPatterns(errors: ErrorInfo[], timeframe: string = '24h'): Promise<{
    patterns: ErrorPattern[];
    trends: ErrorTrend[];
  }> {
    try {
      this.logger.debug(`Detecting patterns in ${errors.length} errors over ${timeframe}`);

      // Prepare error data for pattern analysis
      const errorSummaries = errors.map(error => ({
        id: error.id,
        message: error.message,
        type: error.type,
        file: error.file,
        timestamp: error.timestamp
      }));

      // Use AI to identify patterns
      const { object: patternAnalysis } = await generateObject({
        model: this.aiModel,
        schema: ErrorPatternSchema,
        prompt: `Analyze these errors to identify patterns and trends:

Errors (${errors.length} total):
${JSON.stringify(errorSummaries, null, 2)}

Timeframe: ${timeframe}

Identify:
1. Common error patterns (similar messages, types, or locations)
2. Trends in error frequency or types
3. Suggestions for preventing these patterns

Focus on actionable insights that can help improve code quality.`,
      });

      // Convert AI analysis to our data structures
      const patterns: ErrorPattern[] = patternAnalysis.patterns.map(p => ({
        pattern: p.pattern,
        frequency: p.frequency,
        impact: p.impact,
        suggestion: p.suggestion,
        firstSeen: new Date(Date.now() - 24 * 60 * 60 * 1000), // Placeholder
        lastSeen: new Date(),
        affectedFiles: this.extractAffectedFiles(errors, p.pattern)
      }));

      const trends: ErrorTrend[] = patternAnalysis.trends.map(t => ({
        trend: t.trend,
        direction: t.direction,
        timeframe: t.timeframe,
        recommendation: t.recommendation,
        dataPoints: this.generateTrendDataPoints(errors, t.trend)
      }));

      this.errorPatterns = patterns;
      this.errorTrends = trends;

      this.emit('patternsDetected', { patterns, trends });
      this.logger.info(`Detected ${patterns.length} patterns and ${trends.length} trends`);

      return { patterns, trends };

    } catch (error) {
      this.logger.error("Failed to detect patterns with AI:", error);
      throw error;
    }
  }

  /**
   * Group related errors using AI
   */
  async groupErrors(errors: ErrorInfo[]): Promise<ErrorGroup[]> {
    try {
      this.logger.debug(`Grouping ${errors.length} errors using AI`);

      // Prepare error data for grouping
      const errorData = errors.map(error => ({
        id: error.id,
        message: error.message,
        type: error.type,
        stack: error.stack?.substring(0, 500), // Truncate for AI processing
        file: error.file,
        line: error.line
      }));

      // Use AI to group related errors
      const { object: groupingAnalysis } = await generateObject({
        model: this.aiModel,
        schema: ErrorGroupingSchema,
        prompt: `Group these related errors and identify duplicates:

Errors:
${JSON.stringify(errorData, null, 2)}

Group errors that:
1. Have the same root cause
2. Are duplicates or very similar
3. Occur in related code areas
4. Share common patterns

Provide meaningful group titles and descriptions, and prioritize groups by impact.`,
      });

      // Convert AI analysis to our data structures
      const groups: ErrorGroup[] = groupingAnalysis.groups.map(g => ({
        groupId: g.groupId,
        title: g.title,
        description: g.description,
        errorIds: g.errorIds,
        rootCause: g.rootCause,
        priority: g.priority,
        estimatedEffort: g.estimatedEffort,
        createdAt: new Date(),
        updatedAt: new Date()
      }));

      this.errorGroups = groups;
      this.emit('errorsGrouped', groups);
      this.logger.info(`Created ${groups.length} error groups`);

      return groups;

    } catch (error) {
      this.logger.error("Failed to group errors with AI:", error);
      throw error;
    }
  }

  /**
   * Get error analysis by ID
   */
  getErrorAnalysis(errorId: string): ErrorAnalysis | undefined {
    return this.errorAnalyses.get(errorId);
  }

  /**
   * Get all error patterns
   */
  getErrorPatterns(): ErrorPattern[] {
    return this.errorPatterns;
  }

  /**
   * Get error trends
   */
  getErrorTrends(): ErrorTrend[] {
    return this.errorTrends;
  }

  /**
   * Get error groups
   */
  getErrorGroups(): ErrorGroup[] {
    return this.errorGroups;
  }

  /**
   * Prepare context for error analysis
   */
  private prepareErrorContext(error: ErrorInfo): string {
    const context = [];
    
    if (error.file) {
      context.push(`File: ${error.file}`);
    }

    if (error.line) {
      context.push(`Line: ${error.line}`);
    }

    if (error.context?.userAgent) {
      context.push(`Browser: ${error.context.userAgent}`);
    }
    
    return context.join(', ') || 'No additional context';
  }

  /**
   * Find related errors based on similarity
   */
  private async findRelatedErrors(error: ErrorInfo): Promise<string[]> {
    // Simple implementation - could be enhanced with AI similarity analysis
    const related: string[] = [];
    
    for (const [id, analysis] of this.errorAnalyses) {
      if (id !== error.id && 
          (analysis.category === error.type || 
           error.message.includes(analysis.category))) {
        related.push(id);
      }
    }
    
    return related.slice(0, 5); // Limit to 5 related errors
  }

  /**
   * Generate tags for error categorization
   */
  private generateTags(error: ErrorInfo, categorization: any): string[] {
    const tags = [categorization.category, categorization.severity];
    
    if (error.file) {
      const fileExt = error.file.split('.').pop();
      if (fileExt) tags.push(fileExt);
    }
    
    if (error.message.toLowerCase().includes('react')) {
      tags.push('react');
    }
    
    if (error.message.toLowerCase().includes('async') || 
        error.message.toLowerCase().includes('promise')) {
      tags.push('async');
    }
    
    return tags;
  }

  /**
   * Extract affected files from errors based on pattern
   */
  private extractAffectedFiles(errors: ErrorInfo[], pattern: string): string[] {
    const files = new Set<string>();
    
    errors.forEach(error => {
      if (error.file && error.message.includes(pattern)) {
        files.add(error.file);
      }
    });
    
    return Array.from(files);
  }

  /**
   * Generate trend data points for visualization
   */
  private generateTrendDataPoints(errors: ErrorInfo[], trend: string): Array<{ timestamp: Date; count: number }> {
    // Simple implementation - group errors by hour
    const hourlyData = new Map<string, number>();
    
    errors.forEach(error => {
      const hour = new Date(error.timestamp).toISOString().substring(0, 13);
      hourlyData.set(hour, (hourlyData.get(hour) || 0) + 1);
    });
    
    return Array.from(hourlyData.entries()).map(([hour, count]) => ({
      timestamp: new Date(hour + ':00:00.000Z'),
      count
    }));
  }

  /**
   * Create fallback analysis when AI is not available
   */
  private createFallbackAnalysis(error: ErrorInfo): ErrorAnalysis {
    // Simple rule-based categorization
    let category = "unknown";
    let severity: "critical" | "high" | "medium" | "low" = "medium";

    if (error.message.toLowerCase().includes("syntax")) {
      category = "syntax_error";
      severity = "high";
    } else if (error.message.toLowerCase().includes("type")) {
      category = "type_error";
      severity = "medium";
    } else if (error.message.toLowerCase().includes("reference")) {
      category = "reference_error";
      severity = "high";
    } else if (error.message.toLowerCase().includes("network") || error.message.toLowerCase().includes("fetch")) {
      category = "network_error";
      severity = "medium";
    } else if (error.message.toLowerCase().includes("react")) {
      category = "react_error";
      severity = "medium";
    }

    const analysis: ErrorAnalysis = {
      errorId: error.id,
      timestamp: new Date(),
      category,
      subcategory: "basic_classification",
      severity,
      confidence: 0.6, // Lower confidence for rule-based analysis
      reasoning: "Rule-based classification (AI not available)",
      suggestions: [
        "Check the error message for specific details",
        "Review the stack trace for the error location",
        "Verify the code syntax and types",
        "Consider enabling AI analysis for better insights"
      ],
      relatedErrors: [],
      tags: [category, severity, "fallback"]
    };

    this.errorAnalyses.set(error.id, analysis);
    this.emit('errorAnalyzed', analysis);

    return analysis;
  }

  async shutdown(): Promise<void> {
    this.logger.info("AIErrorAnalyzer shutdown complete");
  }
}
