#!/usr/bin/env node

/**
 * Test script for AI-enhanced MCP features
 * 
 * This script connects to the MCP server and tests the new AI-powered tools:
 * - analyze-errors-ai
 * - get-performance-insights
 * - analyze-code-quality-ai
 * - suggest-optimizations
 */

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class MCPAITester {
  constructor() {
    this.serverProcess = null;
    this.testResults = [];
  }

  async runTest() {
    console.log('🤖 Testing AI-Enhanced MCP Features\n');
    
    try {
      // Test 1: Analyze code quality with AI
      console.log('📊 Testing AI Code Quality Analysis...');
      await this.testCodeQualityAnalysis();
      
      // Test 2: Get performance insights
      console.log('\n⚡ Testing AI Performance Insights...');
      await this.testPerformanceInsights();
      
      // Test 3: Get optimization suggestions
      console.log('\n💡 Testing AI Optimization Suggestions...');
      await this.testOptimizationSuggestions();
      
      // Test 4: Analyze errors with AI (if any errors exist)
      console.log('\n🔍 Testing AI Error Analysis...');
      await this.testErrorAnalysis();
      
      this.printSummary();
      
    } catch (error) {
      console.error('❌ Test failed:', error);
      process.exit(1);
    }
  }

  async testCodeQualityAnalysis() {
    try {
      const result = await this.callMCPTool('analyze-code-quality-ai', {
        filePath: './test-app/src/components/ProblematicComponent.tsx'
      });
      
      if (result && result.overallQualityScore !== undefined) {
        console.log(`✅ Code Quality Analysis successful`);
        console.log(`   Quality Score: ${result.overallQualityScore}/100`);
        console.log(`   Code Smells: ${result.codeSmells?.length || 0}`);
        console.log(`   Refactoring Opportunities: ${result.refactoringOpportunities?.length || 0}`);
        console.log(`   Technical Debt Items: ${result.technicalDebt?.length || 0}`);
        
        if (result.codeSmells?.length > 0) {
          console.log(`   Sample Code Smell: ${result.codeSmells[0].type} (${result.codeSmells[0].severity})`);
        }
        
        this.testResults.push({ test: 'Code Quality Analysis', status: 'PASS', details: result });
      } else {
        console.log('⚠️  Code Quality Analysis returned unexpected format');
        this.testResults.push({ test: 'Code Quality Analysis', status: 'PARTIAL', details: result });
      }
    } catch (error) {
      console.log(`❌ Code Quality Analysis failed: ${error.message}`);
      this.testResults.push({ test: 'Code Quality Analysis', status: 'FAIL', error: error.message });
    }
  }

  async testPerformanceInsights() {
    try {
      const result = await this.callMCPTool('get-performance-insights', {});
      
      if (result && result.overallScore !== undefined) {
        console.log(`✅ Performance Insights successful`);
        console.log(`   Overall Score: ${result.overallScore}/100`);
        console.log(`   Bottlenecks: ${result.bottlenecks?.length || 0}`);
        console.log(`   Suggestions: ${result.suggestions?.length || 0}`);
        console.log(`   Alert Level: ${result.alertLevel || 'none'}`);
        
        if (result.bottlenecks?.length > 0) {
          console.log(`   Sample Bottleneck: ${result.bottlenecks[0].type} (${result.bottlenecks[0].severity})`);
        }
        
        this.testResults.push({ test: 'Performance Insights', status: 'PASS', details: result });
      } else {
        console.log('⚠️  Performance Insights returned unexpected format');
        this.testResults.push({ test: 'Performance Insights', status: 'PARTIAL', details: result });
      }
    } catch (error) {
      console.log(`❌ Performance Insights failed: ${error.message}`);
      this.testResults.push({ test: 'Performance Insights', status: 'FAIL', error: error.message });
    }
  }

  async testOptimizationSuggestions() {
    try {
      const result = await this.callMCPTool('suggest-optimizations', {
        category: 'quickWins'
      });
      
      if (result && Array.isArray(result)) {
        console.log(`✅ Optimization Suggestions successful`);
        console.log(`   Quick Wins: ${result.length}`);
        
        if (result.length > 0) {
          console.log(`   Sample Suggestion: ${result[0].title || result[0].type || 'Optimization available'}`);
        }
        
        this.testResults.push({ test: 'Optimization Suggestions', status: 'PASS', details: result });
      } else if (result && typeof result === 'object') {
        console.log(`✅ Optimization Suggestions successful`);
        console.log(`   Performance Suggestions: ${result.performance?.length || 0}`);
        console.log(`   Code Quality Suggestions: ${result.codeQuality?.length || 0}`);
        console.log(`   Quick Wins: ${result.quickWins?.length || 0}`);
        console.log(`   Critical Issues: ${result.criticalIssues?.length || 0}`);
        
        this.testResults.push({ test: 'Optimization Suggestions', status: 'PASS', details: result });
      } else {
        console.log('⚠️  Optimization Suggestions returned unexpected format');
        this.testResults.push({ test: 'Optimization Suggestions', status: 'PARTIAL', details: result });
      }
    } catch (error) {
      console.log(`❌ Optimization Suggestions failed: ${error.message}`);
      this.testResults.push({ test: 'Optimization Suggestions', status: 'FAIL', error: error.message });
    }
  }

  async testErrorAnalysis() {
    try {
      const result = await this.callMCPTool('analyze-errors-ai', {});
      
      if (result) {
        console.log(`✅ Error Analysis successful`);
        
        if (result.patterns) {
          console.log(`   Error Patterns: ${result.patterns.patterns?.length || 0}`);
          console.log(`   Error Trends: ${result.patterns.trends?.length || 0}`);
        }
        
        if (result.groups) {
          console.log(`   Error Groups: ${result.groups.length || 0}`);
        }
        
        if (result.insights) {
          console.log(`   Total Errors Analyzed: ${result.insights.totalErrors || 0}`);
        }
        
        this.testResults.push({ test: 'Error Analysis', status: 'PASS', details: result });
      } else {
        console.log('⚠️  Error Analysis returned no data (may be no errors to analyze)');
        this.testResults.push({ test: 'Error Analysis', status: 'PARTIAL', details: 'No errors to analyze' });
      }
    } catch (error) {
      console.log(`❌ Error Analysis failed: ${error.message}`);
      this.testResults.push({ test: 'Error Analysis', status: 'FAIL', error: error.message });
    }
  }

  async callMCPTool(toolName, params) {
    return new Promise((resolve, reject) => {
      const mcpProcess = spawn('node', ['test-mcp-client.js', toolName, JSON.stringify(params)], {
        cwd: __dirname,
        stdio: ['pipe', 'pipe', 'pipe']
      });

      let stdout = '';
      let stderr = '';

      mcpProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      mcpProcess.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      mcpProcess.on('close', (code) => {
        if (code === 0) {
          try {
            // Try to parse the JSON response
            const lines = stdout.trim().split('\n');
            const lastLine = lines[lines.length - 1];
            
            if (lastLine.startsWith('{') || lastLine.startsWith('[')) {
              const result = JSON.parse(lastLine);
              resolve(result);
            } else {
              // Look for JSON in the output
              const jsonMatch = stdout.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
              if (jsonMatch) {
                const result = JSON.parse(jsonMatch[0]);
                resolve(result);
              } else {
                resolve(stdout);
              }
            }
          } catch (error) {
            console.log('Raw output:', stdout);
            resolve(stdout);
          }
        } else {
          reject(new Error(`MCP call failed: ${stderr || stdout}`));
        }
      });

      mcpProcess.on('error', (error) => {
        reject(error);
      });
    });
  }

  printSummary() {
    console.log('\n' + '='.repeat(60));
    console.log('🎯 AI-Enhanced MCP Features Test Summary');
    console.log('='.repeat(60));
    
    const passed = this.testResults.filter(r => r.status === 'PASS').length;
    const partial = this.testResults.filter(r => r.status === 'PARTIAL').length;
    const failed = this.testResults.filter(r => r.status === 'FAIL').length;
    
    console.log(`✅ Passed: ${passed}`);
    console.log(`⚠️  Partial: ${partial}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`📊 Total: ${this.testResults.length}`);
    
    console.log('\nDetailed Results:');
    this.testResults.forEach((result, index) => {
      const status = result.status === 'PASS' ? '✅' : result.status === 'PARTIAL' ? '⚠️' : '❌';
      console.log(`${index + 1}. ${status} ${result.test}`);
      if (result.error) {
        console.log(`   Error: ${result.error}`);
      }
    });
    
    if (passed === this.testResults.length) {
      console.log('\n🎉 All AI-enhanced features are working correctly!');
    } else if (passed + partial === this.testResults.length) {
      console.log('\n✨ AI-enhanced features are mostly working with some minor issues.');
    } else {
      console.log('\n⚠️  Some AI-enhanced features need attention.');
    }
    
    console.log('\n💡 Next steps:');
    console.log('1. Open the test app at http://localhost:3000');
    console.log('2. Interact with the components to generate errors and performance data');
    console.log('3. Use the MCP tools to analyze the real-time data');
    console.log('4. Test the AI analysis with actual application behavior');
  }
}

// Run the test
const tester = new MCPAITester();
tester.runTest().catch(console.error);
