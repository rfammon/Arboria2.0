/**
 * AIPerformanceAnalyzer - AI-powered performance analysis and optimization
 * 
 * Uses Vercel AI SDK to provide intelligent performance analysis including:
 * - AI-powered bottleneck identification
 * - Performance regression detection and alerting
 * - Resource optimization opportunity suggestions
 * - User experience impact analysis and recommendations
 */

import { EventEmitter } from "events";
import { generateObject, generateText } from "ai";
import { openai } from "@ai-sdk/openai";
import { z } from "zod";
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { PerformanceMetrics } from "../core/DebuggerCore.js";

// Zod schemas for structured AI outputs
const BottleneckAnalysisSchema = z.object({
  bottlenecks: z.array(z.object({
    type: z.enum([
      "cpu_intensive",
      "memory_leak",
      "network_slow",
      "render_blocking",
      "bundle_size",
      "database_query",
      "api_latency",
      "dom_manipulation",
      "event_handling",
      "state_updates"
    ]).describe("Type of performance bottleneck"),
    severity: z.enum(["critical", "high", "medium", "low"]).describe("Severity of the bottleneck"),
    location: z.string().describe("Where the bottleneck occurs (file, function, component)"),
    description: z.string().describe("Detailed description of the bottleneck"),
    impact: z.string().describe("Impact on user experience"),
    confidence: z.number().min(0).max(1).describe("Confidence in this analysis"),
    estimatedImprovement: z.string().describe("Expected performance improvement if fixed")
  })),
  overallScore: z.number().min(0).max(100).describe("Overall performance score"),
  priorityOrder: z.array(z.string()).describe("Recommended order to fix bottlenecks")
});

const OptimizationSuggestionSchema = z.object({
  suggestions: z.array(z.object({
    category: z.enum([
      "code_optimization",
      "bundle_optimization",
      "caching_strategy",
      "lazy_loading",
      "memory_management",
      "network_optimization",
      "rendering_optimization",
      "state_management",
      "architecture_improvement"
    ]).describe("Category of optimization"),
    title: z.string().describe("Short title for the suggestion"),
    description: z.string().describe("Detailed description of the optimization"),
    implementation: z.string().describe("How to implement this optimization"),
    effort: z.enum(["low", "medium", "high"]).describe("Implementation effort required"),
    impact: z.enum(["low", "medium", "high"]).describe("Expected performance impact"),
    codeExample: z.string().optional().describe("Code example if applicable"),
    priority: z.number().min(1).max(10).describe("Priority score (1-10)")
  })),
  quickWins: z.array(z.string()).describe("Quick optimization wins with minimal effort"),
  longTermGoals: z.array(z.string()).describe("Long-term performance goals")
});

const RegressionAnalysisSchema = z.object({
  regressions: z.array(z.object({
    metric: z.string().describe("Performance metric that regressed"),
    previousValue: z.number().describe("Previous performance value"),
    currentValue: z.number().describe("Current performance value"),
    changePercent: z.number().describe("Percentage change (negative for regression)"),
    severity: z.enum(["critical", "high", "medium", "low"]).describe("Regression severity"),
    likelyCause: z.string().describe("Most likely cause of the regression"),
    affectedFeatures: z.array(z.string()).describe("Features affected by this regression"),
    recommendation: z.string().describe("Recommended action to fix regression")
  })),
  trend: z.enum(["improving", "stable", "degrading"]).describe("Overall performance trend"),
  alertLevel: z.enum(["none", "warning", "critical"]).describe("Alert level for performance")
});

export interface PerformanceBottleneck {
  id: string;
  type: string;
  severity: "critical" | "high" | "medium" | "low";
  location: string;
  description: string;
  impact: string;
  confidence: number;
  estimatedImprovement: string;
  detectedAt: Date;
  status: "open" | "investigating" | "fixed" | "ignored";
}

export interface OptimizationSuggestion {
  id: string;
  category: string;
  title: string;
  description: string;
  implementation: string;
  effort: "low" | "medium" | "high";
  impact: "low" | "medium" | "high";
  codeExample?: string;
  priority: number;
  createdAt: Date;
  status: "pending" | "in_progress" | "completed" | "dismissed";
}

export interface PerformanceRegression {
  id: string;
  metric: string;
  previousValue: number;
  currentValue: number;
  changePercent: number;
  severity: "critical" | "high" | "medium" | "low";
  likelyCause: string;
  affectedFeatures: string[];
  recommendation: string;
  detectedAt: Date;
  resolvedAt?: Date;
}

export interface PerformanceInsight {
  overallScore: number;
  bottlenecks: PerformanceBottleneck[];
  suggestions: OptimizationSuggestion[];
  regressions: PerformanceRegression[];
  trend: "improving" | "stable" | "degrading";
  alertLevel: "none" | "warning" | "critical";
  lastAnalyzed: Date;
}

export class AIPerformanceAnalyzer extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private performanceHistory: PerformanceMetrics[] = [];
  private bottlenecks: Map<string, PerformanceBottleneck> = new Map();
  private suggestions: Map<string, OptimizationSuggestion> = new Map();
  private regressions: Map<string, PerformanceRegression> = new Map();
  private aiModel: any;

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("AIPerformanceAnalyzer");
    this.configManager = configManager;
    
    // Initialize AI model
    const config = this.configManager.getConfig();

    // Check if AI is enabled and API key is available
    if (config.ai?.enabled && (config.ai?.apiKey || process.env.OPENAI_API_KEY)) {
      this.aiModel = openai(config.ai?.model || 'gpt-4o-mini');
    } else {
      this.logger.warn("AI features disabled: No API key provided or AI disabled in config");
      this.aiModel = null;
    }
  }

  async initialize(): Promise<void> {
    this.logger.info("AIPerformanceAnalyzer initialized with AI-powered analysis");
  }

  /**
   * Analyze performance metrics and identify bottlenecks using AI
   */
  async analyzePerformance(metrics: PerformanceMetrics[]): Promise<PerformanceInsight> {
    try {
      this.logger.debug(`Analyzing ${metrics.length} performance metrics with AI`);

      // Check if AI is available
      if (!this.aiModel) {
        return this.createFallbackInsight(metrics);
      }

      // Store metrics for trend analysis
      this.performanceHistory.push(...metrics);
      
      // Keep only recent metrics (last 1000 entries)
      if (this.performanceHistory.length > 1000) {
        this.performanceHistory = this.performanceHistory.slice(-1000);
      }

      // Prepare performance data for AI analysis
      const performanceData = this.preparePerformanceData(metrics);

      // Use AI to identify bottlenecks
      const { object: bottleneckAnalysis } = await generateObject({
        model: this.aiModel,
        schema: BottleneckAnalysisSchema,
        prompt: `Analyze these performance metrics to identify bottlenecks and performance issues:

Performance Data:
${JSON.stringify(performanceData, null, 2)}

Identify:
1. Performance bottlenecks and their severity
2. Root causes of performance issues
3. Impact on user experience
4. Priority order for fixing issues

Focus on actionable insights that can improve application performance.`,
      });

      // Generate optimization suggestions
      const { object: optimizations } = await generateObject({
        model: this.aiModel,
        schema: OptimizationSuggestionSchema,
        prompt: `Based on this performance analysis, provide specific optimization suggestions:

Bottlenecks Found:
${JSON.stringify(bottleneckAnalysis.bottlenecks, null, 2)}

Performance Data:
${JSON.stringify(performanceData, null, 2)}

Provide:
1. Specific, actionable optimization suggestions
2. Implementation guidance with code examples where helpful
3. Effort vs impact analysis
4. Quick wins and long-term goals

Focus on React/Next.js specific optimizations where applicable.`,
      });

      // Check for performance regressions
      const regressionAnalysis = await this.detectRegressions(metrics);

      // Convert AI analysis to our data structures
      const bottlenecks = this.convertBottlenecks(bottleneckAnalysis.bottlenecks);
      const suggestions = this.convertSuggestions(optimizations.suggestions);

      const insight: PerformanceInsight = {
        overallScore: bottleneckAnalysis.overallScore,
        bottlenecks,
        suggestions,
        regressions: Array.from(this.regressions.values()),
        trend: regressionAnalysis.trend,
        alertLevel: regressionAnalysis.alertLevel,
        lastAnalyzed: new Date()
      };

      this.emit('performanceAnalyzed', insight);
      this.logger.info(`Performance analysis complete: ${bottlenecks.length} bottlenecks, ${suggestions.length} suggestions`);

      return insight;

    } catch (error) {
      this.logger.error("Failed to analyze performance with AI:", error);
      throw error;
    }
  }

  /**
   * Detect performance regressions using AI
   */
  async detectRegressions(currentMetrics: PerformanceMetrics[]): Promise<{
    regressions: PerformanceRegression[];
    trend: "improving" | "stable" | "degrading";
    alertLevel: "none" | "warning" | "critical";
  }> {
    try {
      if (this.performanceHistory.length < 10) {
        // Not enough historical data for regression analysis
        return {
          regressions: [],
          trend: "stable",
          alertLevel: "none"
        };
      }

      // Compare current metrics with historical baseline
      const baseline = this.calculateBaseline();
      const current = this.calculateCurrent(currentMetrics);

      // Use AI to analyze regressions
      const { object: regressionAnalysis } = await generateObject({
        model: this.aiModel,
        schema: RegressionAnalysisSchema,
        prompt: `Analyze these performance metrics for regressions:

Baseline Performance (historical average):
${JSON.stringify(baseline, null, 2)}

Current Performance:
${JSON.stringify(current, null, 2)}

Identify:
1. Performance regressions (metrics that got worse)
2. Severity of each regression
3. Likely causes of performance degradation
4. Recommendations for fixing regressions

Consider a regression significant if performance decreased by more than 10%.`,
      });

      // Convert to our data structures
      const regressions = regressionAnalysis.regressions.map(r => ({
        id: `regression_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        metric: r.metric,
        previousValue: r.previousValue,
        currentValue: r.currentValue,
        changePercent: r.changePercent,
        severity: r.severity,
        likelyCause: r.likelyCause,
        affectedFeatures: r.affectedFeatures,
        recommendation: r.recommendation,
        detectedAt: new Date()
      }));

      // Store regressions
      regressions.forEach(regression => {
        this.regressions.set(regression.id, regression);
      });

      this.emit('regressionsDetected', regressions);
      this.logger.info(`Detected ${regressions.length} performance regressions`);

      return {
        regressions,
        trend: regressionAnalysis.trend,
        alertLevel: regressionAnalysis.alertLevel
      };

    } catch (error) {
      this.logger.error("Failed to detect regressions with AI:", error);
      return {
        regressions: [],
        trend: "stable",
        alertLevel: "none"
      };
    }
  }

  /**
   * Get performance insights
   */
  getPerformanceInsights(): PerformanceInsight {
    return {
      overallScore: this.calculateOverallScore(),
      bottlenecks: Array.from(this.bottlenecks.values()),
      suggestions: Array.from(this.suggestions.values()),
      regressions: Array.from(this.regressions.values()),
      trend: this.calculateTrend(),
      alertLevel: this.calculateAlertLevel(),
      lastAnalyzed: new Date()
    };
  }

  /**
   * Get bottlenecks by severity
   */
  getBottlenecksBySeverity(severity: "critical" | "high" | "medium" | "low"): PerformanceBottleneck[] {
    return Array.from(this.bottlenecks.values()).filter(b => b.severity === severity);
  }

  /**
   * Get optimization suggestions by impact
   */
  getSuggestionsByImpact(impact: "high" | "medium" | "low"): OptimizationSuggestion[] {
    return Array.from(this.suggestions.values())
      .filter(s => s.impact === impact)
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * Prepare performance data for AI analysis
   */
  private preparePerformanceData(metrics: PerformanceMetrics[]): any {
    if (metrics.length === 0) return {};

    const latest = metrics[metrics.length - 1];
    const summary = {
      browser: latest?.browser,
      build: latest?.build,
      runtime: latest?.runtime,
      trends: this.calculateTrends(metrics),
      averages: this.calculateAverages(metrics)
    };

    return summary;
  }

  /**
   * Convert AI bottleneck analysis to our data structure
   */
  private convertBottlenecks(aiBottlenecks: any[]): PerformanceBottleneck[] {
    return aiBottlenecks.map(b => {
      const bottleneck: PerformanceBottleneck = {
        id: `bottleneck_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: b.type,
        severity: b.severity,
        location: b.location,
        description: b.description,
        impact: b.impact,
        confidence: b.confidence,
        estimatedImprovement: b.estimatedImprovement,
        detectedAt: new Date(),
        status: "open"
      };

      this.bottlenecks.set(bottleneck.id, bottleneck);
      return bottleneck;
    });
  }

  /**
   * Convert AI suggestions to our data structure
   */
  private convertSuggestions(aiSuggestions: any[]): OptimizationSuggestion[] {
    return aiSuggestions.map(s => {
      const suggestion: OptimizationSuggestion = {
        id: `suggestion_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: s.category,
        title: s.title,
        description: s.description,
        implementation: s.implementation,
        effort: s.effort,
        impact: s.impact,
        codeExample: s.codeExample,
        priority: s.priority,
        createdAt: new Date(),
        status: "pending"
      };

      this.suggestions.set(suggestion.id, suggestion);
      return suggestion;
    });
  }

  /**
   * Calculate baseline performance from historical data
   */
  private calculateBaseline(): any {
    if (this.performanceHistory.length === 0) return {};

    const recentHistory = this.performanceHistory.slice(-50); // Last 50 metrics
    return this.calculateAverages(recentHistory);
  }

  /**
   * Calculate current performance averages
   */
  private calculateCurrent(metrics: PerformanceMetrics[]): any {
    return this.calculateAverages(metrics);
  }

  /**
   * Calculate performance averages
   */
  private calculateAverages(metrics: PerformanceMetrics[]): any {
    if (metrics.length === 0) return {};

    const totals = metrics.reduce((acc, metric) => {
      if (metric.browser) {
        acc.memoryUsage += metric.browser.memoryUsage || 0;
        acc.cpuUsage += metric.browser.cpuUsage || 0;
        acc.networkRequests += metric.browser.networkRequests || 0;
        acc.renderTime += metric.browser.renderTime || 0;
      }
      if (metric.runtime) {
        acc.componentRenders += metric.runtime.componentRenders || 0;
        acc.hookUpdates += metric.runtime.hookUpdates || 0;
        acc.stateChanges += metric.runtime.stateChanges || 0;
      }
      return acc;
    }, {
      memoryUsage: 0,
      cpuUsage: 0,
      networkRequests: 0,
      renderTime: 0,
      componentRenders: 0,
      hookUpdates: 0,
      stateChanges: 0
    });

    const count = metrics.length;
    return {
      memoryUsage: totals.memoryUsage / count,
      cpuUsage: totals.cpuUsage / count,
      networkRequests: totals.networkRequests / count,
      renderTime: totals.renderTime / count,
      componentRenders: totals.componentRenders / count,
      hookUpdates: totals.hookUpdates / count,
      stateChanges: totals.stateChanges / count
    };
  }

  /**
   * Calculate performance trends
   */
  private calculateTrends(metrics: PerformanceMetrics[]): any {
    // Simple trend calculation - could be enhanced
    if (metrics.length < 2) return {};

    const first = metrics[0];
    const last = metrics[metrics.length - 1];

    return {
      memoryTrend: this.calculateTrendDirection(first?.browser?.memoryUsage, last?.browser?.memoryUsage),
      cpuTrend: this.calculateTrendDirection(first?.browser?.cpuUsage, last?.browser?.cpuUsage),
      renderTrend: this.calculateTrendDirection(first?.browser?.renderTime, last?.browser?.renderTime)
    };
  }

  /**
   * Calculate trend direction
   */
  private calculateTrendDirection(first?: number, last?: number): string {
    if (!first || !last) return "stable";
    
    const change = ((last - first) / first) * 100;
    if (change > 10) return "increasing";
    if (change < -10) return "decreasing";
    return "stable";
  }

  /**
   * Calculate overall performance score
   */
  private calculateOverallScore(): number {
    const criticalBottlenecks = this.getBottlenecksBySeverity("critical").length;
    const highBottlenecks = this.getBottlenecksBySeverity("high").length;
    const mediumBottlenecks = this.getBottlenecksBySeverity("medium").length;

    let score = 100;
    score -= criticalBottlenecks * 25;
    score -= highBottlenecks * 15;
    score -= mediumBottlenecks * 5;

    return Math.max(0, score);
  }

  /**
   * Calculate performance trend
   */
  private calculateTrend(): "improving" | "stable" | "degrading" {
    const recentRegressions = Array.from(this.regressions.values())
      .filter(r => r.detectedAt > new Date(Date.now() - 24 * 60 * 60 * 1000));

    if (recentRegressions.length > 2) return "degrading";
    if (recentRegressions.length === 0) return "improving";
    return "stable";
  }

  /**
   * Calculate alert level
   */
  private calculateAlertLevel(): "none" | "warning" | "critical" {
    const criticalIssues = this.getBottlenecksBySeverity("critical").length +
                          Array.from(this.regressions.values()).filter(r => r.severity === "critical").length;

    if (criticalIssues > 0) return "critical";

    const highIssues = this.getBottlenecksBySeverity("high").length +
                      Array.from(this.regressions.values()).filter(r => r.severity === "high").length;

    if (highIssues > 2) return "warning";
    return "none";
  }

  /**
   * Create fallback insight when AI is not available
   */
  private createFallbackInsight(metrics: PerformanceMetrics[]): PerformanceInsight {
    // Simple rule-based analysis
    const bottlenecks: PerformanceBottleneck[] = [];
    const suggestions: OptimizationSuggestion[] = [];

    // Basic performance checks
    if (metrics.length > 0) {
      const latest = metrics[metrics.length - 1];

      // Check memory usage
      if (latest?.browser?.memoryUsage && latest.browser.memoryUsage > 100 * 1024 * 1024) { // 100MB
        bottlenecks.push({
          id: `bottleneck_memory_${Date.now()}`,
          type: "memory_leak",
          severity: "high",
          location: "Browser memory",
          description: "High memory usage detected",
          impact: "May cause browser slowdown",
          confidence: 0.7,
          estimatedImprovement: "20-30% performance improvement",
          detectedAt: new Date(),
          status: "open"
        });

        suggestions.push({
          id: `suggestion_memory_${Date.now()}`,
          category: "memory_management",
          title: "Optimize Memory Usage",
          description: "Consider implementing memory optimization strategies",
          implementation: "Review component lifecycle and cleanup unused references",
          effort: "medium",
          impact: "high",
          priority: 8,
          createdAt: new Date(),
          status: "pending"
        });
      }

      // Check render time
      if (latest?.browser?.renderTime && latest.browser.renderTime > 16) { // 16ms for 60fps
        bottlenecks.push({
          id: `bottleneck_render_${Date.now()}`,
          type: "render_blocking",
          severity: "medium",
          location: "Render pipeline",
          description: "Slow render times detected",
          impact: "May cause frame drops",
          confidence: 0.8,
          estimatedImprovement: "Smoother user experience",
          detectedAt: new Date(),
          status: "open"
        });
      }
    }

    const insight: PerformanceInsight = {
      overallScore: 75, // Default score
      bottlenecks,
      suggestions,
      regressions: [],
      trend: "stable",
      alertLevel: bottlenecks.some(b => b.severity === "critical") ? "critical" :
                  bottlenecks.some(b => b.severity === "high") ? "warning" : "none",
      lastAnalyzed: new Date()
    };

    this.emit('performanceAnalyzed', insight);
    return insight;
  }

  async shutdown(): Promise<void> {
    this.logger.info("AIPerformanceAnalyzer shutdown complete");
  }
}
