// Utility file with various complexity and code quality issues

// Issue: Using 'any' types extensively
export const processData = (input: any, options: any): any => {
  // Issue: High cyclomatic complexity
  if (input) {
    if (typeof input === 'string') {
      if (input.length > 0) {
        if (input.includes(' ')) {
          if (input.startsWith('data:')) {
            if (input.includes('base64')) {
              if (options && options.decode) {
                if (options.format === 'json') {
                  try {
                    return JSON.parse(atob(input.split(',')[1]));
                  } catch (e) {
                    return null;
                  }
                } else if (options.format === 'text') {
                  return atob(input.split(',')[1]);
                } else {
                  return input;
                }
              } else {
                return input;
              }
            } else {
              return input.substring(5);
            }
          } else {
            return input.split(' ').map(word => word.trim()).filter(Boolean);
          }
        } else {
          return [input];
        }
      } else {
        return [];
      }
    } else if (typeof input === 'number') {
      if (input > 0) {
        if (input > 100) {
          return input * 2;
        } else {
          return input * 1.5;
        }
      } else {
        return 0;
      }
    } else if (Array.isArray(input)) {
      return input.map(item => processData(item, options));
    } else {
      return input;
    }
  } else {
    return null;
  }
};

// Issue: Function with too many parameters
export const complexCalculation = (
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
  g: number,
  h: number // 8 parameters > 5 threshold
): number => {
  return a + b * c - d / e + f * g - h;
};

// Issue: Bad naming convention
export const helper_function_bad_name = (data: any) => {
  return data?.value || 0;
};

// Issue: Deeply nested function with high complexity
export const validateUserInput = (input: any): boolean => {
  if (input) {
    if (typeof input === 'object') {
      if (input.user) {
        if (input.user.name) {
          if (input.user.name.length > 0) {
            if (input.user.email) {
              if (input.user.email.includes('@')) {
                if (input.user.email.includes('.')) {
                  if (input.user.age) {
                    if (input.user.age >= 18) {
                      if (input.user.permissions) {
                        if (Array.isArray(input.user.permissions)) {
                          if (input.user.permissions.length > 0) {
                            return true;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return false;
};

// Issue: Large function that should be broken down
export const massiveDataProcessor = (dataset: any[]): any => {
  const results = [];
  const errors = [];
  const warnings = [];
  const metadata = {
    processed: 0,
    skipped: 0,
    errors: 0,
    startTime: Date.now()
  };

  // Issue: Nested loops with high complexity
  for (let i = 0; i < dataset.length; i++) {
    const item = dataset[i];
    
    try {
      if (item && typeof item === 'object') {
        const processed = { ...item };
        
        // Complex processing logic
        for (const key in item) {
          if (item.hasOwnProperty(key)) {
            const value = item[key];
            
            if (typeof value === 'string') {
              if (value.length > 100) {
                processed[key] = value.substring(0, 100) + '...';
                warnings.push(`Truncated long string in ${key}`);
              } else if (value.includes('script')) {
                processed[key] = value.replace(/script/gi, '[SCRIPT]');
                warnings.push(`Sanitized script tag in ${key}`);
              } else if (value.match(/^\d+$/)) {
                processed[key] = parseInt(value, 10);
              } else if (value.match(/^\d+\.\d+$/)) {
                processed[key] = parseFloat(value);
              }
            } else if (typeof value === 'number') {
              if (value > 1000000) {
                processed[key] = Math.round(value / 1000) + 'K';
              } else if (value < 0) {
                processed[key] = 0;
                warnings.push(`Negative value converted to 0 in ${key}`);
              }
            } else if (Array.isArray(value)) {
              processed[key] = value.filter(v => v !== null && v !== undefined);
              
              if (processed[key].length !== value.length) {
                warnings.push(`Filtered null/undefined values from array in ${key}`);
              }
            }
          }
        }
        
        // Validation
        if (processed.id && processed.name) {
          results.push(processed);
          metadata.processed++;
        } else {
          metadata.skipped++;
          warnings.push(`Skipped item ${i} due to missing id or name`);
        }
      } else {
        metadata.skipped++;
        warnings.push(`Skipped item ${i} - not an object`);
      }
    } catch (error) {
      errors.push(`Error processing item ${i}: ${error.message}`);
      metadata.errors++;
    }
  }

  metadata.endTime = Date.now();
  metadata.duration = metadata.endTime - metadata.startTime;

  return {
    results,
    errors,
    warnings,
    metadata
  };
};

// Issue: Function with side effects and no clear purpose
export const doEverything = (input: any): any => {
  // Issue: Modifying global state
  if (typeof window !== 'undefined') {
    window.lastProcessedData = input;
  }

  // Issue: Console logging in utility function
  console.log('Processing:', input);

  // Issue: Synchronous localStorage access
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('lastInput', JSON.stringify(input));
  }

  // Issue: Network request in utility function
  fetch('/api/log', {
    method: 'POST',
    body: JSON.stringify({ action: 'process', data: input })
  }).catch(() => {
    // Silent error handling
  });

  return processData(input, { decode: true, format: 'json' });
};

// Issue: Utility class with too many responsibilities
export class DataManager {
  private cache: any = {};
  private listeners: any[] = [];
  private config: any = {};

  constructor(config: any) {
    this.config = config;
  }

  // Issue: Method with high complexity
  public processAndStore(data: any, key: string): any {
    if (data) {
      if (typeof data === 'object') {
        if (Array.isArray(data)) {
          if (data.length > 0) {
            const processed = data.map(item => {
              if (item && typeof item === 'object') {
                const result = { ...item };
                if (this.config.transform) {
                  if (typeof this.config.transform === 'function') {
                    try {
                      return this.config.transform(result);
                    } catch (error) {
                      console.error('Transform error:', error);
                      return result;
                    }
                  }
                }
                return result;
              }
              return item;
            });
            
            this.cache[key] = processed;
            this.notifyListeners(key, processed);
            return processed;
          }
        } else {
          const processed = { ...data };
          this.cache[key] = processed;
          this.notifyListeners(key, processed);
          return processed;
        }
      }
    }
    return null;
  }

  private notifyListeners(key: string, data: any): void {
    this.listeners.forEach(listener => {
      try {
        listener(key, data);
      } catch (error) {
        console.error('Listener error:', error);
      }
    });
  }

  public addListener(listener: any): void {
    this.listeners.push(listener);
  }

  public removeListener(listener: any): void {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }
}
