/**
 * ConfigManager - Manages debugger configuration and rules
 * 
 * Handles:
 * - Default configuration
 * - User configuration loading/saving
 * - Rule validation
 * - Hot-reloading of configuration changes
 */

import { EventEmitter } from "events";
import { readFile, writeFile, access } from "fs/promises";
import { join } from "path";
import { Logger } from "../utils/Logger.js";

export interface DebuggerConfig {
  // Code complexity rules
  complexity: {
    maxFileLines: number;
    maxFunctionComplexity: number;
    maxFunctionParams: number;
    maxNestingDepth: number;
    maxImports: number;
  };

  // Pattern enforcement rules
  patterns: {
    namingConventions: {
      components: string;
      hooks: string;
      constants: string;
      functions: string;
      variables: string;
    };
    importRules: string[];
    componentRules: string[];
    fileStructure: string[];
  };

  // Performance monitoring
  performance: {
    renderTimeThreshold: number;
    memoryLeakThreshold: number;
    bundleSizeThreshold: number;
    networkTimeoutThreshold: number;
    enableProfiling: boolean;
  };

  // Error tracking
  errors: {
    trackConsoleErrors: boolean;
    trackUnhandledRejections: boolean;
    trackNetworkErrors: boolean;
    trackReactErrors: boolean;
    enableStackTraces: boolean;
  };

  // File watching
  watching: {
    enabled: boolean;
    paths: string[];
    ignored: string[];
    includeNodeModules: boolean;
    debounceMs: number;
  };

  // Browser connection
  browser: {
    autoConnect: boolean;
    port: number;
    host: string;
    timeout: number;
    retryAttempts: number;
    retryDelay: number;
  };

  // AI analysis
  ai: {
    enabled: boolean;
    provider: "openai" | "local" | "disabled";
    apiKey?: string;
    model?: string;
    enableErrorCategorization: boolean;
    enablePatternDetection: boolean;
    enablePerformanceInsights: boolean;
  };

  // Streaming
  streaming: {
    enabled: boolean;
    bufferSize: number;
    flushInterval: number;
    enableCompression: boolean;
  };

  // Breakpoint management
  breakpoints: {
    maxRecentHits: number;
    autoRemoveAfterHits?: number;
    enableAnalytics: boolean;
    persistBreakpoints: boolean;
    logpointTimeout: number;
    enableConditionalBreakpoints: boolean;
    enableLogpoints: boolean;
  };
}

export class ConfigManager extends EventEmitter {
  private logger: Logger;
  private config: DebuggerConfig;
  private configPath: string;
  private defaultConfig: DebuggerConfig;

  constructor(configPath?: string) {
    super();
    this.logger = new Logger("ConfigManager");
    this.configPath = configPath || this.findConfigPath();
    this.defaultConfig = this.getDefaultConfig();
    this.config = { ...this.defaultConfig };
  }

  /**
   * Initialize configuration manager
   */
  async initialize(): Promise<void> {
    try {
      this.logger.info("Initializing ConfigManager...");
      
      // Load user configuration if it exists
      await this.loadConfig();
      
      this.logger.info("ConfigManager initialized successfully");
    } catch (error) {
      this.logger.error("Failed to initialize ConfigManager:", error);
      throw error;
    }
  }

  /**
   * Get current configuration
   */
  getConfig(): DebuggerConfig {
    return { ...this.config };
  }

  /**
   * Update configuration
   */
  async updateConfig(updates: Partial<DebuggerConfig>): Promise<void> {
    try {
      // Deep merge updates with current config
      this.config = this.deepMerge(this.config, updates);
      
      // Validate configuration
      this.validateConfig(this.config);
      
      // Save to file
      await this.saveConfig();
      
      // Emit update event
      this.emit("configUpdated", this.config);
      
      this.logger.info("Configuration updated successfully");
    } catch (error) {
      this.logger.error("Failed to update configuration:", error);
      throw error;
    }
  }

  /**
   * Reset configuration to defaults
   */
  async resetConfig(): Promise<void> {
    this.config = { ...this.defaultConfig };
    await this.saveConfig();
    this.emit("configUpdated", this.config);
    this.logger.info("Configuration reset to defaults");
  }

  /**
   * Load configuration from file
   */
  private async loadConfig(): Promise<void> {
    try {
      // Check if config file exists
      await access(this.configPath);
      
      // Read and parse config file
      const configData = await readFile(this.configPath, "utf-8");
      const userConfig = JSON.parse(configData);
      
      // Merge with defaults
      this.config = this.deepMerge(this.defaultConfig, userConfig);
      
      // Validate merged config
      this.validateConfig(this.config);
      
      this.logger.info(`Configuration loaded from ${this.configPath}`);
    } catch (error: any) {
      if (error.code === "ENOENT") {
        this.logger.info("No configuration file found, using defaults");
        // Create default config file
        await this.saveConfig();
      } else {
        this.logger.warn("Failed to load configuration, using defaults:", error);
      }
    }
  }

  /**
   * Save configuration to file
   */
  private async saveConfig(): Promise<void> {
    try {
      const configData = JSON.stringify(this.config, null, 2);
      await writeFile(this.configPath, configData, "utf-8");
      this.logger.debug(`Configuration saved to ${this.configPath}`);
    } catch (error) {
      this.logger.error("Failed to save configuration:", error);
      throw error;
    }
  }

  /**
   * Find configuration file path
   */
  private findConfigPath(): string {
    // Look for config in current directory, then home directory
    const candidates = [
      join(process.cwd(), ".debugger-mcp.json"),
      join(process.cwd(), "debugger-mcp.config.json"),
      join(process.env.HOME || process.env.USERPROFILE || ".", ".debugger-mcp.json")
    ];

    // For now, use the first candidate
    return candidates[0]!;
  }

  /**
   * Get default configuration
   */
  private getDefaultConfig(): DebuggerConfig {
    return {
      complexity: {
        maxFileLines: 300,
        maxFunctionComplexity: 10,
        maxFunctionParams: 5,
        maxNestingDepth: 4,
        maxImports: 20
      },
      patterns: {
        namingConventions: {
          components: "^[A-Z][a-zA-Z0-9]*$",
          hooks: "^use[A-Z][a-zA-Z0-9]*$",
          constants: "^[A-Z_]+$",
          functions: "^[a-z][a-zA-Z0-9]*$",
          variables: "^[a-z][a-zA-Z0-9]*$"
        },
        importRules: [
          "no-relative-imports-beyond-parent",
          "group-external-before-internal",
          "alphabetize-imports"
        ],
        componentRules: [
          "max-props-per-component: 8",
          "require-prop-types",
          "no-inline-styles"
        ],
        fileStructure: [
          "components-in-components-dir",
          "hooks-in-hooks-dir",
          "utils-in-utils-dir"
        ]
      },
      performance: {
        renderTimeThreshold: 16, // 60fps
        memoryLeakThreshold: 50 * 1024 * 1024, // 50MB
        bundleSizeThreshold: 1024 * 1024, // 1MB
        networkTimeoutThreshold: 5000, // 5s
        enableProfiling: true
      },
      errors: {
        trackConsoleErrors: true,
        trackUnhandledRejections: true,
        trackNetworkErrors: true,
        trackReactErrors: true,
        enableStackTraces: true
      },
      watching: {
        enabled: true,
        paths: ["src", "pages", "components", "hooks", "utils"],
        ignored: [
          "node_modules",
          ".git",
          "dist",
          "build",
          ".next",
          "coverage",
          "*.test.*",
          "*.spec.*"
        ],
        includeNodeModules: false,
        debounceMs: 300
      },
      browser: {
        autoConnect: true,
        port: 9222,
        host: "localhost",
        timeout: 10000,
        retryAttempts: 3,
        retryDelay: 2000
      },
      ai: {
        enabled: false, // Disabled by default
        provider: "disabled",
        enableErrorCategorization: false,
        enablePatternDetection: false,
        enablePerformanceInsights: false
      },
      streaming: {
        enabled: true,
        bufferSize: 1000,
        flushInterval: 1000,
        enableCompression: false
      },

      breakpoints: {
        maxRecentHits: 100,
        autoRemoveAfterHits: undefined,
        enableAnalytics: true,
        persistBreakpoints: true,
        logpointTimeout: 5000,
        enableConditionalBreakpoints: true,
        enableLogpoints: true
      }
    };
  }

  /**
   * Validate configuration
   */
  private validateConfig(config: DebuggerConfig): void {
    // Basic validation - could be expanded
    if (config.complexity.maxFileLines <= 0) {
      throw new Error("maxFileLines must be positive");
    }
    if (config.complexity.maxFunctionComplexity <= 0) {
      throw new Error("maxFunctionComplexity must be positive");
    }
    if (config.performance.renderTimeThreshold <= 0) {
      throw new Error("renderTimeThreshold must be positive");
    }
    if (config.browser.port <= 0 || config.browser.port > 65535) {
      throw new Error("browser port must be between 1 and 65535");
    }

    // Breakpoint configuration validation
    if (config.breakpoints.maxRecentHits <= 0) {
      throw new Error("maxRecentHits must be positive");
    }
    if (config.breakpoints.autoRemoveAfterHits !== undefined && config.breakpoints.autoRemoveAfterHits <= 0) {
      throw new Error("autoRemoveAfterHits must be positive when specified");
    }
    if (config.breakpoints.logpointTimeout <= 0) {
      throw new Error("logpointTimeout must be positive");
    }
  }

  /**
   * Deep merge two objects
   */
  private deepMerge(target: any, source: any): any {
    const result = { ...target };
    
    for (const key in source) {
      if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(target[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }
    
    return result;
  }
}
