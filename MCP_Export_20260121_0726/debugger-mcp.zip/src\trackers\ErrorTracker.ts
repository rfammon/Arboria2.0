/**
 * ErrorTracker - Error collection and management
 */

import { EventEmitter } from "events";
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { ErrorInfo } from "../core/DebuggerCore.js";

export class ErrorTracker extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private errors: ErrorInfo[] = [];

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("ErrorTracker");
    this.configManager = configManager;
  }

  async initialize(): Promise<void> {
    this.logger.info("ErrorTracker initialized");
  }

  addError(error: ErrorInfo): void {
    this.errors.push(error);
    this.emit("error", error);
  }

  async getErrors(options: {
    severity?: "error" | "warning" | "info";
    timeframe?: string;
  } = {}): Promise<ErrorInfo[]> {
    let filtered = [...this.errors];
    
    if (options.severity) {
      filtered = filtered.filter(e => e.severity === options.severity);
    }
    
    return filtered.slice(-100); // Return last 100 errors
  }

  getErrorCount(): number {
    return this.errors.length;
  }

  async shutdown(): Promise<void> {
    this.logger.info("ErrorTracker shutdown complete");
  }
}
