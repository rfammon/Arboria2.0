#!/usr/bin/env node

/**
 * Debugger MCP Server
 */

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { fileURLToPath } from 'node:url';
import path from 'node:path';

import { DebuggerCore } from "./core/DebuggerCore.js";
import { ConfigManager } from "./config/ConfigManager.js";
import { Logger } from "./utils/Logger.js";

const logger = new Logger("DebuggerMCP");

const server = new McpServer({
  name: "debugger-mcp-server",
  version: "1.0.0"
});

async function initializeServer() {
  try {
    logger.info("Initializing Debugger MCP Server...");
    const configManager = new ConfigManager();
    await configManager.initialize();
    const debuggerCore = new DebuggerCore(configManager);
    await debuggerCore.initialize();
    await registerTools(debuggerCore);
    await registerResources(debuggerCore);
    logger.info("Debugger MCP Server initialized successfully");
    return { debuggerCore, configManager };
  } catch (error) {
    logger.error("Failed to initialize server:", error);
    throw error;
  }
}

async function registerTools(debuggerCore: DebuggerCore) {
  server.registerTool(
    "debugger-action",
    {
      title: "Debugger Action",
      description: "Unified tool for all debugging, metrics, profiling, and analysis operations.",
      inputSchema: {
        action: z.enum([
          "get-metrics",
          "performance-profiling",
          "analyze-performance",
          "analyze-react",
          "analyze-ai",
          "debug-variables",
          "get-debug-session",
          "analyze-complexity",
          "manage-breakpoints",
          "browser-control",
          "update-config"
        ]).describe("Action to perform"),
        params: z.any().describe("Arguments for the action")
      }
    },
    async ({ action, params }) => {
      let data;
      try {
        switch (action) {
          case "get-metrics":
            data = await (async () => {
              const { type, severity, timeframe, limit, filePath } = params || {};
              switch (type) {
                case "errors": return await debuggerCore.getErrors({ severity, timeframe });
                case "violations": return await debuggerCore.getViolations({ severity, filePath });
                case "performance": return await debuggerCore.getPerformanceMetrics({ timeframe, limit });
                case "network": return await debuggerCore.getNetworkMetrics(limit);
                case "render": return await debuggerCore.getRenderMetrics(limit);
                case "memory": return await debuggerCore.getMemorySnapshots(limit);
                default: throw new Error(`Invalid metric type: ${type}`);
              }
            })();
            break;
          case "performance-profiling":
            data = await (async () => {
              const { action: pAction, profileId, title, samplingInterval } = params || {};
              switch (pAction) {
                case "start-cpu": return { success: true, profileId: await debuggerCore.startCPUProfiling(title) };
                case "stop-cpu": return { success: true, profile: await debuggerCore.stopCPUProfiling(profileId) };
                case "take-heap-snapshot": return { success: true, snapshot: await debuggerCore.takeDetailedHeapSnapshot() };
                case "start-heap-sampling": await debuggerCore.startHeapSampling(samplingInterval); return { success: true };
                case "stop-heap-sampling": return { success: true, profile: await debuggerCore.stopHeapSampling() };
                case "force-gc": await debuggerCore.forceGarbageCollection(); return { success: true };
                default: throw new Error(`Invalid profiling action: ${pAction}`);
              }
            })();
            break;
          case "analyze-performance":
            data = await (async () => {
              const { type: aType, timeframe = 300000 } = params || {};
              switch (aType) {
                case "network": return await debuggerCore.analyzeNetworkPerformance(timeframe);
                case "render": return await debuggerCore.analyzeRenderPerformance(timeframe);
                case "dashboard":
                  const [net, ren, alr] = await Promise.all([
                    debuggerCore.analyzeNetworkPerformance(timeframe),
                    debuggerCore.analyzeRenderPerformance(timeframe),
                    debuggerCore.getPerformanceAlerts(false)
                  ]);
                  return { net, ren, alerts: alr.slice(0, 5) };
                case "recommendations": return await debuggerCore.getPerformanceOptimizationRecommendations(timeframe);
                default: throw new Error(`Invalid analysis type: ${aType}`);
              }
            })();
            break;
          case "analyze-react":
            data = await (async () => {
              const { action: rAction, filePath, componentName, hookType, issueType, timeframe } = params || {};
              switch (rAction) {
                case "component": return await debuggerCore.analyzeReactComponent(filePath, componentName);
                case "hooks": return await debuggerCore.analyzeReactHooks(filePath, hookType);
                case "performance": return await debuggerCore.getReactPerformanceMetrics({ timeframe, componentName });
                case "detect-issues": return await debuggerCore.detectReactIssues({ filePath, issueType });
                default: throw new Error(`Invalid react action: ${rAction}`);
              }
            })();
            break;
          case "analyze-ai":
            data = await (async () => {
              const { type: aiType, errorId, filePath, category } = params || {};
              switch (aiType) {
                case "errors": return await debuggerCore.analyzeErrorsWithAI(errorId);
                case "performance": return await debuggerCore.getPerformanceInsightsWithAI();
                case "code-quality": return await debuggerCore.analyzeCodeQualityWithAI(filePath);
                case "optimizations": return await debuggerCore.getOptimizationSuggestions(category);
                default: throw new Error(`Invalid AI type: ${aiType}`);
              }
            })();
            break;
          case "debug-variables":
            data = await debuggerCore.executeVariableCommand(params);
            break;
          case "get-debug-session":
            data = await debuggerCore.getDebugSession();
            break;
          case "analyze-complexity":
            data = await debuggerCore.analyzeComplexity(params.filePath);
            break;
          case "manage-breakpoints":
            data = await debuggerCore.executeBreakpointCommand(params);
            break;
          case "browser-control":
            const { action: bAction, throttling } = params || {};
            if (bAction === "clear-cache") await debuggerCore.clearBrowserCache();
            else if (bAction === "clear-cookies") await debuggerCore.clearBrowserCookies();
            else if (bAction === "set-throttling" && throttling) await debuggerCore.setNetworkThrottling(throttling);
            data = { success: true };
            break;
          case "update-config":
            data = await debuggerCore.updateConfig(params.config);
            break;
          default:
            throw new Error(`Unknown action: ${action}`);
        }
      } catch (error) {
        data = { success: false, error: error instanceof Error ? error.message : String(error) };
      }
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );
  logger.info("MCP tools registered successfully (Extreme Consolidation: 1 Unified Tool)");
}

async function registerResources(debuggerCore: DebuggerCore) {
  server.registerResource("error-stream", "stream://errors", { title: "Error Stream", description: "Real-time stream of errors", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, text: JSON.stringify(await debuggerCore.getErrorStream(), null, 2) }] }));

  server.registerResource("violation-stream", "stream://violations", { title: "Violation Stream", description: "Real-time stream of violations", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, text: JSON.stringify(await debuggerCore.getViolationStream(), null, 2) }] }));

  server.registerResource("performance-stream", "stream://performance", { title: "Performance Stream", description: "Real-time stream of performance", mimeType: "application/json" },
    async (uri) => ({ contents: [{ uri: uri.href, text: JSON.stringify(await debuggerCore.getPerformanceStream(), null, 2) }] }));

  logger.info("MCP resources registered successfully");
}

async function main() {
  try {
    const { debuggerCore } = await initializeServer();
    const transport = new StdioServerTransport();
    await server.connect(transport);
    logger.info("Debugger MCP Server is running");
    process.on('SIGINT', async () => { await debuggerCore.shutdown(); process.exit(0); });
    process.on('SIGTERM', async () => { await debuggerCore.shutdown(); process.exit(0); });
  } catch (error) {
    logger.error("Failed to start server:", error);
    process.exit(1);
  }
}

if (process.argv[1] && (path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url)))) {
  main().catch((error) => {
    console.error("Fatal error:", error);
    process.exit(1);
  });
}
