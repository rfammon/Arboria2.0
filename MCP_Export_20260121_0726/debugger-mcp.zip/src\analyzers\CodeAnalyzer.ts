/**
 * CodeAnalyzer - Real-time code quality analysis
 * 
 * Handles:
 * - AST parsing with Babel
 * - Complexity analysis
 * - Rule violation detection
 * - Pattern matching
 * - Code quality scoring
 */

import { EventEmitter } from "events";
import { createRequire } from "module";
import { readFile } from "fs/promises";
import { parse } from "@babel/parser";

const require = createRequire(import.meta.url);
const traverse = require("@babel/traverse").default || require("@babel/traverse");
import { ConfigManager } from "../config/ConfigManager.js";
import { Logger } from "../utils/Logger.js";
import type { ViolationInfo, ComplexityAnalysis } from "../core/DebuggerCore.js";

export class CodeAnalyzer extends EventEmitter {
  private logger: Logger;
  private configManager: ConfigManager;
  private violations = new Map<string, ViolationInfo[]>();

  constructor(configManager: ConfigManager) {
    super();
    this.logger = new Logger("CodeAnalyzer");
    this.configManager = configManager;
  }

  /**
   * Initialize code analyzer
   */
  async initialize(): Promise<void> {
    try {
      this.logger.info("Initializing CodeAnalyzer...");
      this.logger.info("CodeAnalyzer initialized successfully");
    } catch (error) {
      this.logger.error("Failed to initialize CodeAnalyzer:", error);
      throw error;
    }
  }

  /**
   * Analyze a file for code quality issues
   */
  async analyzeFile(filePath: string): Promise<void> {
    try {
      this.logger.debug(`Analyzing file: ${filePath}`);

      // Read file content
      const content = await readFile(filePath, "utf-8");

      // Parse AST
      const ast = this.parseCode(content, filePath);
      if (!ast) return;

      // Analyze complexity and violations
      const analysis = await this.analyzeComplexity(filePath);

      // Store violations
      this.violations.set(filePath, analysis.violations);

      // Emit violations
      for (const violation of analysis.violations) {
        this.emit("violation", violation);
      }

    } catch (error) {
      this.logger.error(`Failed to analyze file ${filePath}:`, error);
    }
  }

  /**
   * Analyze file complexity
   */
  async analyzeComplexity(filePath: string): Promise<ComplexityAnalysis> {
    try {
      const content = await readFile(filePath, "utf-8");
      const ast = this.parseCode(content, filePath);

      if (!ast) {
        return this.createEmptyAnalysis(filePath);
      }

      const metrics = this.calculateMetrics(ast, content);
      const violations = this.checkRules(ast, filePath, content);
      const score = this.calculateScore(metrics, violations);

      return {
        file: filePath,
        timestamp: new Date(),
        metrics,
        violations,
        score
      };
    } catch (error) {
      this.logger.error(`Failed to analyze complexity for ${filePath}:`, error);
      return this.createEmptyAnalysis(filePath);
    }
  }

  /**
   * Get violations with optional filtering
   */
  async getViolations(options: {
    severity?: "error" | "warning" | "info";
    filePath?: string;
  } = {}): Promise<ViolationInfo[]> {
    let allViolations: ViolationInfo[] = [];

    if (options.filePath) {
      allViolations = this.violations.get(options.filePath) || [];
    } else {
      for (const violations of this.violations.values()) {
        allViolations.push(...violations);
      }
    }

    if (options.severity) {
      allViolations = allViolations.filter(v => v.severity === options.severity);
    }

    return allViolations.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  /**
   * Get violation count
   */
  getViolationCount(): number {
    let count = 0;
    for (const violations of this.violations.values()) {
      count += violations.length;
    }
    return count;
  }

  /**
   * Parse code into AST
   */
  private parseCode(content: string, filePath: string): any {
    try {
      const isTypeScript = filePath.endsWith('.ts') || filePath.endsWith('.tsx');
      const isJSX = filePath.endsWith('.jsx') || filePath.endsWith('.tsx');

      const plugins: any[] = [];
      if (isTypeScript) plugins.push('typescript');
      if (isJSX) plugins.push('jsx');

      return parse(content, {
        sourceType: 'module',
        allowImportExportEverywhere: true,
        allowReturnOutsideFunction: true,
        plugins
      });
    } catch (error) {
      this.logger.warn(`Failed to parse ${filePath}:`, error);
      return null;
    }
  }

  /**
   * Calculate code metrics
   */
  private calculateMetrics(ast: any, content: string): ComplexityAnalysis['metrics'] {
    const lines = content.split('\n');
    let functionCount = 0;
    let maxFunctionComplexity = 0;
    let maxFunctionParams = 0;
    let maxNestingDepth = 0;
    let totalComplexity = 0;

    const self = this;
    traverse(ast, {
      Function(path: any) {
        functionCount++;

        // Calculate cyclomatic complexity for this function
        const complexity = self.calculateCyclomaticComplexityForPath(path);
        totalComplexity += complexity;
        maxFunctionComplexity = Math.max(maxFunctionComplexity, complexity);

        // Count parameters
        const paramCount = path.node.params?.length || 0;
        maxFunctionParams = Math.max(maxFunctionParams, paramCount);

        // Calculate nesting depth
        const depth = self.calculateNestingDepthForPath(path);
        maxNestingDepth = Math.max(maxNestingDepth, depth);
      }
    });

    return {
      cyclomaticComplexity: totalComplexity,
      linesOfCode: lines.length,
      functionCount,
      maxFunctionComplexity,
      maxFunctionParams,
      maxNestingDepth
    };
  }

  /**
   * Calculate cyclomatic complexity (simplified)
   */
  private calculateCyclomaticComplexityForPath(path: any): number {
    let complexity = 1; // Base complexity

    path.traverse({
      IfStatement: () => { complexity++; },
      ConditionalExpression: () => { complexity++; },
      LogicalExpression: () => { complexity++; },
      SwitchCase: () => { complexity++; },
      WhileStatement: () => { complexity++; },
      DoWhileStatement: () => { complexity++; },
      ForStatement: () => { complexity++; },
      ForInStatement: () => { complexity++; },
      ForOfStatement: () => { complexity++; },
      CatchClause: () => { complexity++; }
    });

    return complexity;
  }

  /**
   * Calculate nesting depth (simplified)
   */
  private calculateNestingDepthForPath(path: any): number {
    let maxDepth = 0;
    let currentDepth = 0;

    path.traverse({
      enter(innerPath: any) {
        if (innerPath.isBlockStatement() || innerPath.isFunction()) {
          currentDepth++;
          maxDepth = Math.max(maxDepth, currentDepth);
        }
      },
      exit(innerPath: any) {
        if (innerPath.isBlockStatement() || innerPath.isFunction()) {
          currentDepth--;
        }
      }
    });

    return maxDepth;
  }

  /**
   * Check rules and generate violations
   */
  private checkRules(ast: any, filePath: string, content: string): ViolationInfo[] {
    const violations: ViolationInfo[] = [];
    const config = this.configManager.getConfig();
    const lines = content.split('\n');

    // Check file length
    if (lines.length > config.complexity.maxFileLines) {
      violations.push({
        id: this.generateId(),
        timestamp: new Date(),
        rule: "max-file-lines",
        severity: "warning",
        message: `File has ${lines.length} lines, exceeds limit of ${config.complexity.maxFileLines}`,
        file: filePath,
        category: "complexity",
        suggestion: "Consider breaking this file into smaller modules"
      });
    }

    // Add more rule checks here...

    return violations;
  }

  /**
   * Calculate overall score
   */
  private calculateScore(metrics: ComplexityAnalysis['metrics'], violations: ViolationInfo[]): "excellent" | "good" | "fair" | "poor" {
    const errorCount = violations.filter(v => v.severity === "error").length;
    const warningCount = violations.filter(v => v.severity === "warning").length;

    if (errorCount > 0) return "poor";
    if (warningCount > 5) return "fair";
    if (warningCount > 2) return "good";
    return "excellent";
  }

  /**
   * Create empty analysis for failed parsing
   */
  private createEmptyAnalysis(filePath: string): ComplexityAnalysis {
    return {
      file: filePath,
      timestamp: new Date(),
      metrics: {
        cyclomaticComplexity: 0,
        linesOfCode: 0,
        functionCount: 0,
        maxFunctionComplexity: 0,
        maxFunctionParams: 0,
        maxNestingDepth: 0
      },
      violations: [],
      score: "excellent"
    };
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return `analyzer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Shutdown code analyzer
   */
  async shutdown(): Promise<void> {
    try {
      this.logger.info("Shutting down CodeAnalyzer...");
      this.violations.clear();
      this.logger.info("CodeAnalyzer shutdown complete");
    } catch (error) {
      this.logger.error("Error during CodeAnalyzer shutdown:", error);
      throw error;
    }
  }
}
