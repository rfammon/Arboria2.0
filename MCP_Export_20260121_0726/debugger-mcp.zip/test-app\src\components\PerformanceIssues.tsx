'use client';

import React, { useState, useEffect, useMemo } from 'react';

// Component focused on performance issues
interface PerformanceIssuesProps {
  items: any[]; // Issue: using 'any'
  threshold: number;
}

// Issue: Component name doesn't follow convention (should be descriptive)
const PerformanceIssues: React.FC<PerformanceIssuesProps> = ({ items, threshold }) => {
  const [data, setData] = useState<any[]>([]); // Issue: using 'any'
  const [filter, setFilter] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Issue: Expensive operation without proper memoization
  const processedData = items.map(item => {
    // Expensive processing for each item on every render
    let processed = { ...item };
    for (let i = 0; i < 1000; i++) {
      processed.value = Math.sin(processed.value || 0) * Math.cos(i);
    }
    return processed;
  });

  // Issue: useMemo with missing dependencies
  const filteredData = useMemo(() => {
    return processedData.filter(item => 
      item.name?.toLowerCase().includes(filter.toLowerCase())
    );
  }, [filter]); // Missing 'processedData' dependency

  // Issue: Expensive calculation in useEffect without proper dependencies
  useEffect(() => {
    const expensiveCalculation = () => {
      let result = [];
      for (let i = 0; i < items.length * 1000; i++) {
        result.push(Math.random() * i);
      }
      return result;
    };
    
    setData(expensiveCalculation());
  }, []); // Missing 'items' dependency

  // Issue: Memory leak - event listener without cleanup
  useEffect(() => {
    const handleScroll = () => {
      console.log('Scrolling...');
    };
    
    window.addEventListener('scroll', handleScroll);
    // Missing cleanup
  }, []);

  // Issue: Creating objects in render (causes unnecessary re-renders)
  const styles = {
    container: { padding: '20px', margin: '10px' },
    item: { border: '1px solid #ccc', padding: '10px' },
    button: { backgroundColor: 'blue', color: 'white' }
  };

  // Issue: Function defined in render (recreated on every render)
  const handleSort = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  // Issue: Inline function in JSX (recreated on every render)
  const renderItem = (item: any, index: number) => {
    return (
      <div 
        key={index} 
        style={styles.item}
        onClick={() => console.log('Clicked item:', item)} // Inline function
      >
        <h3>{item.name}</h3>
        <p>{item.description}</p>
        <span>{item.value}</span>
      </div>
    );
  };

  // Issue: No key optimization for list rendering
  const renderList = () => {
    return filteredData.map((item, index) => {
      // Issue: Using index as key (bad for performance)
      return (
        <div key={index} className="border p-2 m-1">
          {/* Issue: Expensive operation in render */}
          <span>{JSON.stringify(item).length} characters</span>
          <div>{item.name}</div>
          {/* Issue: Conditional rendering that could be optimized */}
          {item.value > threshold && (
            <div style={{ color: 'red' }}>High value!</div>
          )}
        </div>
      );
    });
  };

  // Issue: Large component with too many responsibilities
  const renderComplexSection = () => {
    const complexData = [];
    
    // Issue: Heavy computation in render
    for (let i = 0; i < 1000; i++) {
      complexData.push({
        id: i,
        computed: Math.pow(i, 2) * Math.sin(i) * Math.cos(i),
        nested: {
          deep: {
            value: Math.random() * i
          }
        }
      });
    }

    return (
      <div>
        <h2>Complex Section</h2>
        {complexData.slice(0, 10).map((item, idx) => (
          <div key={idx} style={{ border: '1px solid black', margin: '2px' }}>
            <span>ID: {item.id}</span>
            <span>Computed: {item.computed.toFixed(4)}</span>
            <span>Deep: {item.nested.deep.value.toFixed(4)}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={styles.container}>
      <h1>Performance Issues Component</h1>
      
      <div className="controls mb-4">
        <input
          type="text"
          placeholder="Filter items..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="border p-2 mr-2"
        />
        
        <button 
          onClick={handleSort}
          style={styles.button}
          className="p-2 rounded"
        >
          Sort {sortOrder}
        </button>
      </div>

      <div className="stats mb-4">
        <p>Total items: {items.length}</p>
        <p>Filtered items: {filteredData.length}</p>
        <p>Processed data length: {processedData.length}</p>
        <p>Data state length: {data.length}</p>
      </div>

      <div className="items-list">
        {renderList()}
      </div>

      {renderComplexSection()}

      {/* Issue: Inline styles and complex conditional rendering */}
      <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#f5f5f5' }}>
        {items.length > 100 && (
          <div style={{ color: 'orange', fontWeight: 'bold' }}>
            Warning: Large dataset detected!
          </div>
        )}
        
        {filteredData.length === 0 && filter.length > 0 && (
          <div style={{ color: 'red', textAlign: 'center' }}>
            No items match your filter
          </div>
        )}
      </div>
    </div>
  );
};

export default PerformanceIssues;
