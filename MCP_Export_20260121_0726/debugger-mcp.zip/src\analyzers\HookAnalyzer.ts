import { Logger } from '../utils/Logger.js';
import * as babel from '@babel/parser';
import * as t from '@babel/types';
import { createRequire } from 'module';

// Use createRequire for traverse to handle ES module compatibility
const require = createRequire(import.meta.url);
const traverse = require('@babel/traverse').default || require('@babel/traverse');

/**
 * Hook analysis results
 */
export interface HookAnalysisResult {
  hooks: HookUsage[];
  violations: HookViolation[];
  performance: HookPerformanceIssue[];
  dependencies: DependencyAnalysis[];
}

export interface HookUsage {
  name: string;
  type: HookType;
  filePath: string;
  lineNumber: number;
  dependencies: string[];
  isConditional: boolean;
  isInLoop: boolean;
  isInCallback: boolean;
}

export interface HookViolation {
  type: 'conditional' | 'loop' | 'nested' | 'dependency' | 'order';
  severity: 'error' | 'warning';
  message: string;
  filePath: string;
  lineNumber: number;
  hookName: string;
  suggestion: string;
}

export interface HookPerformanceIssue {
  type: 'missing-memo' | 'unnecessary-dependency' | 'expensive-calculation' | 'object-dependency';
  severity: 'warning' | 'info';
  message: string;
  filePath: string;
  lineNumber: number;
  hookName: string;
  suggestion: string;
}

export interface DependencyAnalysis {
  hookName: string;
  filePath: string;
  lineNumber: number;
  declared: string[];
  used: string[];
  missing: string[];
  unnecessary: string[];
}

export type HookType = 
  | 'useState' 
  | 'useEffect' 
  | 'useContext' 
  | 'useReducer' 
  | 'useCallback' 
  | 'useMemo' 
  | 'useRef' 
  | 'useImperativeHandle' 
  | 'useLayoutEffect' 
  | 'useDebugValue'
  | 'custom';

/**
 * Analyzes React hooks for compliance with rules of hooks and performance
 */
export class HookAnalyzer {
  private logger: Logger;

  constructor() {
    this.logger = new Logger('HookAnalyzer');
  }

  /**
   * Analyze hooks in a React file
   */
  async analyzeFile(filePath: string, content: string): Promise<HookAnalysisResult> {
    try {
      const ast = babel.parse(content, {
        sourceType: 'module',
        plugins: ['jsx', 'typescript', 'decorators-legacy']
      });

      const result: HookAnalysisResult = {
        hooks: [],
        violations: [],
        performance: [],
        dependencies: []
      };

      let currentFunction: t.Function | null = null;
      let isInConditional = false;
      let isInLoop = false;
      let loopDepth = 0;
      let conditionalDepth = 0;

      traverse(ast, {
        // Track function context
        Function: {
          enter: (path: any) => {
            currentFunction = path.node;
          },
          exit: () => {
            currentFunction = null;
          }
        },

        // Track conditional context
        IfStatement: {
          enter: () => {
            isInConditional = true;
            conditionalDepth++;
          },
          exit: () => {
            conditionalDepth--;
            isInConditional = conditionalDepth > 0;
          }
        },

        ConditionalExpression: {
          enter: () => {
            isInConditional = true;
            conditionalDepth++;
          },
          exit: () => {
            conditionalDepth--;
            isInConditional = conditionalDepth > 0;
          }
        },

        // Track loop context
        WhileStatement: {
          enter: () => {
            isInLoop = true;
            loopDepth++;
          },
          exit: () => {
            loopDepth--;
            isInLoop = loopDepth > 0;
          }
        },

        ForStatement: {
          enter: () => {
            isInLoop = true;
            loopDepth++;
          },
          exit: () => {
            loopDepth--;
            isInLoop = loopDepth > 0;
          }
        },

        // Analyze hook calls
        CallExpression: (path: any) => {
          if (this.isHookCall(path.node)) {
            const hookUsage = this.analyzeHookUsage(
              path, 
              filePath, 
              isInConditional, 
              isInLoop,
              currentFunction
            );
            
            result.hooks.push(hookUsage);

            // Check for violations
            const violations = this.checkHookViolations(hookUsage, path);
            result.violations.push(...violations);

            // Check for performance issues
            const performanceIssues = this.checkPerformanceIssues(hookUsage, path);
            result.performance.push(...performanceIssues);

            // Analyze dependencies for useEffect, useCallback, useMemo
            if (['useEffect', 'useCallback', 'useMemo'].includes(hookUsage.name)) {
              const depAnalysis = this.analyzeDependencies(path, filePath, currentFunction);
              if (depAnalysis) {
                result.dependencies.push(depAnalysis);
              }
            }
          }
        }
      });

      this.logger.info(`Analyzed hooks in file: ${filePath}`, {
        hooks: result.hooks.length,
        violations: result.violations.length,
        performance: result.performance.length
      });

      return result;
    } catch (error) {
      this.logger.error('Failed to analyze hooks', { filePath, error });
      throw error;
    }
  }

  /**
   * Check if a call expression is a hook
   */
  private isHookCall(node: t.CallExpression): boolean {
    if (t.isIdentifier(node.callee)) {
      const name = node.callee.name;
      return name.startsWith('use') && name.length > 3 && name.charAt(3) === name.charAt(3).toUpperCase();
    }
    return false;
  }

  /**
   * Analyze individual hook usage
   */
  private analyzeHookUsage(
    path: any,
    filePath: string,
    isInConditional: boolean,
    isInLoop: boolean,
    currentFunction: t.Function | null
  ): HookUsage {
    const node = path.node;
    const hookName = t.isIdentifier(node.callee) ? node.callee.name : 'unknown';
    
    return {
      name: hookName,
      type: this.getHookType(hookName),
      filePath,
      lineNumber: node.loc?.start.line || 0,
      dependencies: this.extractDependencies(node),
      isConditional: isInConditional,
      isInLoop,
      isInCallback: this.isInCallback(currentFunction)
    };
  }

  /**
   * Get hook type from hook name
   */
  private getHookType(hookName: string): HookType {
    const standardHooks: Record<string, HookType> = {
      'useState': 'useState',
      'useEffect': 'useEffect',
      'useContext': 'useContext',
      'useReducer': 'useReducer',
      'useCallback': 'useCallback',
      'useMemo': 'useMemo',
      'useRef': 'useRef',
      'useImperativeHandle': 'useImperativeHandle',
      'useLayoutEffect': 'useLayoutEffect',
      'useDebugValue': 'useDebugValue'
    };

    return standardHooks[hookName] || 'custom';
  }

  /**
   * Extract dependencies from hook call
   */
  private extractDependencies(node: t.CallExpression): string[] {
    // For hooks with dependency arrays (useEffect, useCallback, useMemo)
    if (node.arguments.length > 1) {
      const depsArg = node.arguments[node.arguments.length - 1];
      if (t.isArrayExpression(depsArg)) {
        return depsArg.elements
          .filter(el => t.isIdentifier(el))
          .map(el => (el as t.Identifier).name);
      }
    }
    return [];
  }

  /**
   * Check if hook is called inside a callback
   */
  private isInCallback(currentFunction: t.Function | null): boolean {
    if (!currentFunction) return false;
    
    // Simple heuristic: if function is an arrow function or anonymous function
    return t.isArrowFunctionExpression(currentFunction) || 
           (t.isFunctionExpression(currentFunction) && !currentFunction.id);
  }

  /**
   * Check for hook rule violations
   */
  private checkHookViolations(hookUsage: HookUsage, path: any): HookViolation[] {
    const violations: HookViolation[] = [];

    // Rule 1: Don't call hooks inside loops, conditions, or nested functions
    if (hookUsage.isConditional) {
      violations.push({
        type: 'conditional',
        severity: 'error',
        message: `Hook "${hookUsage.name}" is called conditionally`,
        filePath: hookUsage.filePath,
        lineNumber: hookUsage.lineNumber,
        hookName: hookUsage.name,
        suggestion: 'Move the condition inside the hook or restructure the component'
      });
    }

    if (hookUsage.isInLoop) {
      violations.push({
        type: 'loop',
        severity: 'error',
        message: `Hook "${hookUsage.name}" is called inside a loop`,
        filePath: hookUsage.filePath,
        lineNumber: hookUsage.lineNumber,
        hookName: hookUsage.name,
        suggestion: 'Move the hook outside the loop or restructure the logic'
      });
    }

    if (hookUsage.isInCallback && hookUsage.type !== 'custom') {
      violations.push({
        type: 'nested',
        severity: 'error',
        message: `Hook "${hookUsage.name}" is called inside a nested function`,
        filePath: hookUsage.filePath,
        lineNumber: hookUsage.lineNumber,
        hookName: hookUsage.name,
        suggestion: 'Only call hooks at the top level of React functions'
      });
    }

    return violations;
  }

  /**
   * Check for performance issues
   */
  private checkPerformanceIssues(hookUsage: HookUsage, path: any): HookPerformanceIssue[] {
    const issues: HookPerformanceIssue[] = [];

    // Check for missing useMemo/useCallback opportunities
    if (hookUsage.name === 'useEffect' && hookUsage.dependencies.length === 0) {
      issues.push({
        type: 'missing-memo',
        severity: 'warning',
        message: 'useEffect with empty dependency array - consider if this should run only once',
        filePath: hookUsage.filePath,
        lineNumber: hookUsage.lineNumber,
        hookName: hookUsage.name,
        suggestion: 'Verify that empty dependency array is intentional'
      });
    }

    // Check for object dependencies that might cause unnecessary re-renders
    const node = path.node;
    if (['useEffect', 'useCallback', 'useMemo'].includes(hookUsage.name)) {
      const hasObjectDependency = this.hasObjectDependency(node);
      if (hasObjectDependency) {
        issues.push({
          type: 'object-dependency',
          severity: 'warning',
          message: `${hookUsage.name} may have object/array dependencies causing unnecessary re-runs`,
          filePath: hookUsage.filePath,
          lineNumber: hookUsage.lineNumber,
          hookName: hookUsage.name,
          suggestion: 'Consider memoizing object/array dependencies or restructuring'
        });
      }
    }

    return issues;
  }

  /**
   * Check if hook has object dependencies
   */
  private hasObjectDependency(node: t.CallExpression): boolean {
    if (node.arguments.length > 1) {
      const depsArg = node.arguments[node.arguments.length - 1];
      if (t.isArrayExpression(depsArg)) {
        return depsArg.elements.some(el => 
          t.isObjectExpression(el) || 
          t.isArrayExpression(el) ||
          (t.isIdentifier(el) && el.name.includes('.'))
        );
      }
    }
    return false;
  }

  /**
   * Analyze dependencies for useEffect, useCallback, useMemo
   */
  private analyzeDependencies(
    path: any, 
    filePath: string, 
    currentFunction: t.Function | null
  ): DependencyAnalysis | null {
    const node = path.node;
    const hookName = t.isIdentifier(node.callee) ? node.callee.name : 'unknown';
    
    if (!currentFunction) return null;

    const declared = this.extractDependencies(node);
    const used = this.findUsedVariables(node.arguments[0], currentFunction);
    
    const missing = used.filter(v => !declared.includes(v));
    const unnecessary = declared.filter(v => !used.includes(v));

    return {
      hookName,
      filePath,
      lineNumber: node.loc?.start.line || 0,
      declared,
      used,
      missing,
      unnecessary
    };
  }

  /**
   * Find variables used in hook callback
   */
  private findUsedVariables(callback: t.Node, functionScope: t.Function): string[] {
    const used: string[] = [];
    const functionParams = this.getFunctionParams(functionScope);

    // Simple variable extraction without traverse
    const extractVariablesRecursive = (n: any): void => {
      if (!n || typeof n !== 'object') return;

      if (t.isIdentifier(n)) {
        const name = n.name;
        // Skip if it's a function parameter
        if (!functionParams.includes(name) && !used.includes(name)) {
          used.push(name);
        }
      }

      // Recursively check all properties
      Object.values(n).forEach(value => {
        if (Array.isArray(value)) {
          value.forEach(item => extractVariablesRecursive(item));
        } else if (value && typeof value === 'object') {
          extractVariablesRecursive(value);
        }
      });
    };

    extractVariablesRecursive(callback);
    return used;
  }

  /**
   * Get function parameter names
   */
  private getFunctionParams(func: t.Function): string[] {
    return func.params
      .filter(param => t.isIdentifier(param))
      .map(param => (param as t.Identifier).name);
  }

  /**
   * Check if identifier is a local variable
   */
  private isLocalVariable(path: any, name: string): boolean {
    // Simple check - in a real implementation, we'd need proper scope analysis
    let scope = path.scope;
    while (scope) {
      if (scope.hasBinding(name)) {
        return true;
      }
      scope = scope.parent;
    }
    return false;
  }

  /**
   * Get hook analysis summary
   */
  getAnalysisSummary(results: HookAnalysisResult[]): {
    totalHooks: number;
    violationCount: number;
    performanceIssueCount: number;
    mostCommonViolations: Array<{ type: string; count: number }>;
    hookUsageStats: Array<{ hook: string; count: number }>;
  } {
    const allViolations = results.flatMap(r => r.violations);
    const allPerformanceIssues = results.flatMap(r => r.performance);
    const allHooks = results.flatMap(r => r.hooks);

    // Count violation types
    const violationCounts = new Map<string, number>();
    allViolations.forEach(v => {
      violationCounts.set(v.type, (violationCounts.get(v.type) || 0) + 1);
    });

    // Count hook usage
    const hookCounts = new Map<string, number>();
    allHooks.forEach(h => {
      hookCounts.set(h.name, (hookCounts.get(h.name) || 0) + 1);
    });

    return {
      totalHooks: allHooks.length,
      violationCount: allViolations.length,
      performanceIssueCount: allPerformanceIssues.length,
      mostCommonViolations: Array.from(violationCounts.entries())
        .map(([type, count]) => ({ type, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5),
      hookUsageStats: Array.from(hookCounts.entries())
        .map(([hook, count]) => ({ hook, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10)
    };
  }
}
