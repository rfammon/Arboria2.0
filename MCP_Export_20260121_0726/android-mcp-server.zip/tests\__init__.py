"""
Android MCP Server Tests

This package contains unit and integration tests for the Android MCP Server.
"""
